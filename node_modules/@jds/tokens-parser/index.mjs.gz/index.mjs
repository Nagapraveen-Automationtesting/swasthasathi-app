import { deepClone, merge, removeBraces, kebabcase, hexToRGB } from '@jds/utils';

var buffer = {};

var base64Js = {};

base64Js.byteLength = byteLength;
base64Js.toByteArray = toByteArray;
base64Js.fromByteArray = fromByteArray;

var lookup = [];
var revLookup = [];
var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array;

var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
for (var i = 0, len = code.length; i < len; ++i) {
  lookup[i] = code[i];
  revLookup[code.charCodeAt(i)] = i;
}

// Support decoding URL-safe base64 strings, as Node.js does.
// See: https://en.wikipedia.org/wiki/Base64#URL_applications
revLookup['-'.charCodeAt(0)] = 62;
revLookup['_'.charCodeAt(0)] = 63;

function getLens (b64) {
  var len = b64.length;

  if (len % 4 > 0) {
    throw new Error('Invalid string. Length must be a multiple of 4')
  }

  // Trim off extra bytes after placeholder bytes are found
  // See: https://github.com/beatgammit/base64-js/issues/42
  var validLen = b64.indexOf('=');
  if (validLen === -1) validLen = len;

  var placeHoldersLen = validLen === len
    ? 0
    : 4 - (validLen % 4);

  return [validLen, placeHoldersLen]
}

// base64 is 4/3 + up to two characters of the original data
function byteLength (b64) {
  var lens = getLens(b64);
  var validLen = lens[0];
  var placeHoldersLen = lens[1];
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function _byteLength (b64, validLen, placeHoldersLen) {
  return ((validLen + placeHoldersLen) * 3 / 4) - placeHoldersLen
}

function toByteArray (b64) {
  var tmp;
  var lens = getLens(b64);
  var validLen = lens[0];
  var placeHoldersLen = lens[1];

  var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));

  var curByte = 0;

  // if there are placeholders, only get up to the last complete 4 chars
  var len = placeHoldersLen > 0
    ? validLen - 4
    : validLen;

  var i;
  for (i = 0; i < len; i += 4) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 18) |
      (revLookup[b64.charCodeAt(i + 1)] << 12) |
      (revLookup[b64.charCodeAt(i + 2)] << 6) |
      revLookup[b64.charCodeAt(i + 3)];
    arr[curByte++] = (tmp >> 16) & 0xFF;
    arr[curByte++] = (tmp >> 8) & 0xFF;
    arr[curByte++] = tmp & 0xFF;
  }

  if (placeHoldersLen === 2) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 2) |
      (revLookup[b64.charCodeAt(i + 1)] >> 4);
    arr[curByte++] = tmp & 0xFF;
  }

  if (placeHoldersLen === 1) {
    tmp =
      (revLookup[b64.charCodeAt(i)] << 10) |
      (revLookup[b64.charCodeAt(i + 1)] << 4) |
      (revLookup[b64.charCodeAt(i + 2)] >> 2);
    arr[curByte++] = (tmp >> 8) & 0xFF;
    arr[curByte++] = tmp & 0xFF;
  }

  return arr
}

function tripletToBase64 (num) {
  return lookup[num >> 18 & 0x3F] +
    lookup[num >> 12 & 0x3F] +
    lookup[num >> 6 & 0x3F] +
    lookup[num & 0x3F]
}

function encodeChunk (uint8, start, end) {
  var tmp;
  var output = [];
  for (var i = start; i < end; i += 3) {
    tmp =
      ((uint8[i] << 16) & 0xFF0000) +
      ((uint8[i + 1] << 8) & 0xFF00) +
      (uint8[i + 2] & 0xFF);
    output.push(tripletToBase64(tmp));
  }
  return output.join('')
}

function fromByteArray (uint8) {
  var tmp;
  var len = uint8.length;
  var extraBytes = len % 3; // if we have 1 byte left, pad 2 bytes
  var parts = [];
  var maxChunkLength = 16383; // must be multiple of 3

  // go through the array every three bytes, we'll deal with trailing stuff later
  for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
    parts.push(encodeChunk(uint8, i, (i + maxChunkLength) > len2 ? len2 : (i + maxChunkLength)));
  }

  // pad the end with zeros, but make sure to not forget the extra bytes
  if (extraBytes === 1) {
    tmp = uint8[len - 1];
    parts.push(
      lookup[tmp >> 2] +
      lookup[(tmp << 4) & 0x3F] +
      '=='
    );
  } else if (extraBytes === 2) {
    tmp = (uint8[len - 2] << 8) + uint8[len - 1];
    parts.push(
      lookup[tmp >> 10] +
      lookup[(tmp >> 4) & 0x3F] +
      lookup[(tmp << 2) & 0x3F] +
      '='
    );
  }

  return parts.join('')
}

var ieee754 = {};

/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */

ieee754.read = function (buffer, offset, isLE, mLen, nBytes) {
  var e, m;
  var eLen = (nBytes * 8) - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var nBits = -7;
  var i = isLE ? (nBytes - 1) : 0;
  var d = isLE ? -1 : 1;
  var s = buffer[offset + i];

  i += d;

  e = s & ((1 << (-nBits)) - 1);
  s >>= (-nBits);
  nBits += eLen;
  for (; nBits > 0; e = (e * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  m = e & ((1 << (-nBits)) - 1);
  e >>= (-nBits);
  nBits += mLen;
  for (; nBits > 0; m = (m * 256) + buffer[offset + i], i += d, nBits -= 8) {}

  if (e === 0) {
    e = 1 - eBias;
  } else if (e === eMax) {
    return m ? NaN : ((s ? -1 : 1) * Infinity)
  } else {
    m = m + Math.pow(2, mLen);
    e = e - eBias;
  }
  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
};

ieee754.write = function (buffer, value, offset, isLE, mLen, nBytes) {
  var e, m, c;
  var eLen = (nBytes * 8) - mLen - 1;
  var eMax = (1 << eLen) - 1;
  var eBias = eMax >> 1;
  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0);
  var i = isLE ? 0 : (nBytes - 1);
  var d = isLE ? 1 : -1;
  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0;

  value = Math.abs(value);

  if (isNaN(value) || value === Infinity) {
    m = isNaN(value) ? 1 : 0;
    e = eMax;
  } else {
    e = Math.floor(Math.log(value) / Math.LN2);
    if (value * (c = Math.pow(2, -e)) < 1) {
      e--;
      c *= 2;
    }
    if (e + eBias >= 1) {
      value += rt / c;
    } else {
      value += rt * Math.pow(2, 1 - eBias);
    }
    if (value * c >= 2) {
      e++;
      c /= 2;
    }

    if (e + eBias >= eMax) {
      m = 0;
      e = eMax;
    } else if (e + eBias >= 1) {
      m = ((value * c) - 1) * Math.pow(2, mLen);
      e = e + eBias;
    } else {
      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
      e = 0;
    }
  }

  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

  e = (e << mLen) | m;
  eLen += mLen;
  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

  buffer[offset + i - d] |= s * 128;
};

/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */

(function (exports) {

	const base64 = base64Js;
	const ieee754$1 = ieee754;
	const customInspectSymbol =
	  (typeof Symbol === 'function' && typeof Symbol['for'] === 'function') // eslint-disable-line dot-notation
	    ? Symbol['for']('nodejs.util.inspect.custom') // eslint-disable-line dot-notation
	    : null;

	exports.Buffer = Buffer;
	exports.SlowBuffer = SlowBuffer;
	exports.INSPECT_MAX_BYTES = 50;

	const K_MAX_LENGTH = 0x7fffffff;
	exports.kMaxLength = K_MAX_LENGTH;
	const { Uint8Array: GlobalUint8Array, ArrayBuffer: GlobalArrayBuffer, SharedArrayBuffer: GlobalSharedArrayBuffer } = globalThis;

	/**
	 * If `Buffer.TYPED_ARRAY_SUPPORT`:
	 *   === true    Use Uint8Array implementation (fastest)
	 *   === false   Print warning and recommend using `buffer` v4.x which has an Object
	 *               implementation (most compatible, even IE6)
	 *
	 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
	 * Opera 11.6+, iOS 4.2+.
	 *
	 * We report that the browser does not support typed arrays if the are not subclassable
	 * using __proto__. Firefox 4-29 lacks support for adding new properties to `Uint8Array`
	 * (See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438). IE 10 lacks support
	 * for __proto__ and has a buggy typed array implementation.
	 */
	Buffer.TYPED_ARRAY_SUPPORT = typedArraySupport();

	if (!Buffer.TYPED_ARRAY_SUPPORT && typeof console !== 'undefined' &&
	    typeof console.error === 'function') {
	  console.error(
	    'This browser lacks typed array (Uint8Array) support which is required by ' +
	    '`buffer` v5.x. Use `buffer` v4.x if you require old browser support.'
	  );
	}

	function typedArraySupport () {
	  // Can typed array instances can be augmented?
	  try {
	    const arr = new GlobalUint8Array(1);
	    const proto = { foo: function () { return 42 } };
	    Object.setPrototypeOf(proto, GlobalUint8Array.prototype);
	    Object.setPrototypeOf(arr, proto);
	    return arr.foo() === 42
	  } catch (e) {
	    return false
	  }
	}

	Object.defineProperty(Buffer.prototype, 'parent', {
	  enumerable: true,
	  get: function () {
	    if (!Buffer.isBuffer(this)) return undefined
	    return this.buffer
	  }
	});

	Object.defineProperty(Buffer.prototype, 'offset', {
	  enumerable: true,
	  get: function () {
	    if (!Buffer.isBuffer(this)) return undefined
	    return this.byteOffset
	  }
	});

	function createBuffer (length) {
	  if (length > K_MAX_LENGTH) {
	    throw new RangeError('The value "' + length + '" is invalid for option "size"')
	  }
	  // Return an augmented `Uint8Array` instance
	  const buf = new GlobalUint8Array(length);
	  Object.setPrototypeOf(buf, Buffer.prototype);
	  return buf
	}

	/**
	 * The Buffer constructor returns instances of `Uint8Array` that have their
	 * prototype changed to `Buffer.prototype`. Furthermore, `Buffer` is a subclass of
	 * `Uint8Array`, so the returned instances will have all the node `Buffer` methods
	 * and the `Uint8Array` methods. Square bracket notation works as expected -- it
	 * returns a single octet.
	 *
	 * The `Uint8Array` prototype remains unmodified.
	 */

	function Buffer (arg, encodingOrOffset, length) {
	  // Common case.
	  if (typeof arg === 'number') {
	    if (typeof encodingOrOffset === 'string') {
	      throw new TypeError(
	        'The "string" argument must be of type string. Received type number'
	      )
	    }
	    return allocUnsafe(arg)
	  }
	  return from(arg, encodingOrOffset, length)
	}

	Buffer.poolSize = 8192; // not used by this implementation

	function from (value, encodingOrOffset, length) {
	  if (typeof value === 'string') {
	    return fromString(value, encodingOrOffset)
	  }

	  if (GlobalArrayBuffer.isView(value)) {
	    return fromArrayView(value)
	  }

	  if (value == null) {
	    throw new TypeError(
	      'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
	      'or Array-like Object. Received type ' + (typeof value)
	    )
	  }

	  if (isInstance(value, GlobalArrayBuffer) ||
	      (value && isInstance(value.buffer, GlobalArrayBuffer))) {
	    return fromArrayBuffer(value, encodingOrOffset, length)
	  }

	  if (typeof GlobalSharedArrayBuffer !== 'undefined' &&
	      (isInstance(value, GlobalSharedArrayBuffer) ||
	      (value && isInstance(value.buffer, GlobalSharedArrayBuffer)))) {
	    return fromArrayBuffer(value, encodingOrOffset, length)
	  }

	  if (typeof value === 'number') {
	    throw new TypeError(
	      'The "value" argument must not be of type number. Received type number'
	    )
	  }

	  const valueOf = value.valueOf && value.valueOf();
	  if (valueOf != null && valueOf !== value) {
	    return Buffer.from(valueOf, encodingOrOffset, length)
	  }

	  const b = fromObject(value);
	  if (b) return b

	  if (typeof Symbol !== 'undefined' && Symbol.toPrimitive != null &&
	      typeof value[Symbol.toPrimitive] === 'function') {
	    return Buffer.from(value[Symbol.toPrimitive]('string'), encodingOrOffset, length)
	  }

	  throw new TypeError(
	    'The first argument must be one of type string, Buffer, ArrayBuffer, Array, ' +
	    'or Array-like Object. Received type ' + (typeof value)
	  )
	}

	/**
	 * Functionally equivalent to Buffer(arg, encoding) but throws a TypeError
	 * if value is a number.
	 * Buffer.from(str[, encoding])
	 * Buffer.from(array)
	 * Buffer.from(buffer)
	 * Buffer.from(arrayBuffer[, byteOffset[, length]])
	 **/
	Buffer.from = function (value, encodingOrOffset, length) {
	  return from(value, encodingOrOffset, length)
	};

	// Note: Change prototype *after* Buffer.from is defined to workaround Chrome bug:
	// https://github.com/feross/buffer/pull/148
	Object.setPrototypeOf(Buffer.prototype, GlobalUint8Array.prototype);
	Object.setPrototypeOf(Buffer, GlobalUint8Array);

	function assertSize (size) {
	  if (typeof size !== 'number') {
	    throw new TypeError('"size" argument must be of type number')
	  } else if (size < 0) {
	    throw new RangeError('The value "' + size + '" is invalid for option "size"')
	  }
	}

	function alloc (size, fill, encoding) {
	  assertSize(size);
	  if (size <= 0) {
	    return createBuffer(size)
	  }
	  if (fill !== undefined) {
	    // Only pay attention to encoding if it's a string. This
	    // prevents accidentally sending in a number that would
	    // be interpreted as a start offset.
	    return typeof encoding === 'string'
	      ? createBuffer(size).fill(fill, encoding)
	      : createBuffer(size).fill(fill)
	  }
	  return createBuffer(size)
	}

	/**
	 * Creates a new filled Buffer instance.
	 * alloc(size[, fill[, encoding]])
	 **/
	Buffer.alloc = function (size, fill, encoding) {
	  return alloc(size, fill, encoding)
	};

	function allocUnsafe (size) {
	  assertSize(size);
	  return createBuffer(size < 0 ? 0 : checked(size) | 0)
	}

	/**
	 * Equivalent to Buffer(num), by default creates a non-zero-filled Buffer instance.
	 * */
	Buffer.allocUnsafe = function (size) {
	  return allocUnsafe(size)
	};
	/**
	 * Equivalent to SlowBuffer(num), by default creates a non-zero-filled Buffer instance.
	 */
	Buffer.allocUnsafeSlow = function (size) {
	  return allocUnsafe(size)
	};

	function fromString (string, encoding) {
	  if (typeof encoding !== 'string' || encoding === '') {
	    encoding = 'utf8';
	  }

	  if (!Buffer.isEncoding(encoding)) {
	    throw new TypeError('Unknown encoding: ' + encoding)
	  }

	  const length = byteLength(string, encoding) | 0;
	  let buf = createBuffer(length);

	  const actual = buf.write(string, encoding);

	  if (actual !== length) {
	    // Writing a hex string, for example, that contains invalid characters will
	    // cause everything after the first invalid character to be ignored. (e.g.
	    // 'abxxcd' will be treated as 'ab')
	    buf = buf.slice(0, actual);
	  }

	  return buf
	}

	function fromArrayLike (array) {
	  const length = array.length < 0 ? 0 : checked(array.length) | 0;
	  const buf = createBuffer(length);
	  for (let i = 0; i < length; i += 1) {
	    buf[i] = array[i] & 255;
	  }
	  return buf
	}

	function fromArrayView (arrayView) {
	  if (isInstance(arrayView, GlobalUint8Array)) {
	    const copy = new GlobalUint8Array(arrayView);
	    return fromArrayBuffer(copy.buffer, copy.byteOffset, copy.byteLength)
	  }
	  return fromArrayLike(arrayView)
	}

	function fromArrayBuffer (array, byteOffset, length) {
	  if (byteOffset < 0 || array.byteLength < byteOffset) {
	    throw new RangeError('"offset" is outside of buffer bounds')
	  }

	  if (array.byteLength < byteOffset + (length || 0)) {
	    throw new RangeError('"length" is outside of buffer bounds')
	  }

	  let buf;
	  if (byteOffset === undefined && length === undefined) {
	    buf = new GlobalUint8Array(array);
	  } else if (length === undefined) {
	    buf = new GlobalUint8Array(array, byteOffset);
	  } else {
	    buf = new GlobalUint8Array(array, byteOffset, length);
	  }

	  // Return an augmented `Uint8Array` instance
	  Object.setPrototypeOf(buf, Buffer.prototype);

	  return buf
	}

	function fromObject (obj) {
	  if (Buffer.isBuffer(obj)) {
	    const len = checked(obj.length) | 0;
	    const buf = createBuffer(len);

	    if (buf.length === 0) {
	      return buf
	    }

	    obj.copy(buf, 0, 0, len);
	    return buf
	  }

	  if (obj.length !== undefined) {
	    if (typeof obj.length !== 'number' || numberIsNaN(obj.length)) {
	      return createBuffer(0)
	    }
	    return fromArrayLike(obj)
	  }

	  if (obj.type === 'Buffer' && Array.isArray(obj.data)) {
	    return fromArrayLike(obj.data)
	  }
	}

	function checked (length) {
	  // Note: cannot use `length < K_MAX_LENGTH` here because that fails when
	  // length is NaN (which is otherwise coerced to zero.)
	  if (length >= K_MAX_LENGTH) {
	    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
	                         'size: 0x' + K_MAX_LENGTH.toString(16) + ' bytes')
	  }
	  return length | 0
	}

	function SlowBuffer (length) {
	  if (+length != length) { // eslint-disable-line eqeqeq
	    length = 0;
	  }
	  return Buffer.alloc(+length)
	}

	Buffer.isBuffer = function isBuffer (b) {
	  return b != null && b._isBuffer === true &&
	    b !== Buffer.prototype // so Buffer.isBuffer(Buffer.prototype) will be false
	};

	Buffer.compare = function compare (a, b) {
	  if (isInstance(a, GlobalUint8Array)) a = Buffer.from(a, a.offset, a.byteLength);
	  if (isInstance(b, GlobalUint8Array)) b = Buffer.from(b, b.offset, b.byteLength);
	  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
	    throw new TypeError(
	      'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
	    )
	  }

	  if (a === b) return 0

	  let x = a.length;
	  let y = b.length;

	  for (let i = 0, len = Math.min(x, y); i < len; ++i) {
	    if (a[i] !== b[i]) {
	      x = a[i];
	      y = b[i];
	      break
	    }
	  }

	  if (x < y) return -1
	  if (y < x) return 1
	  return 0
	};

	Buffer.isEncoding = function isEncoding (encoding) {
	  switch (String(encoding).toLowerCase()) {
	    case 'hex':
	    case 'utf8':
	    case 'utf-8':
	    case 'ascii':
	    case 'latin1':
	    case 'binary':
	    case 'base64':
	    case 'ucs2':
	    case 'ucs-2':
	    case 'utf16le':
	    case 'utf-16le':
	      return true
	    default:
	      return false
	  }
	};

	Buffer.concat = function concat (list, length) {
	  if (!Array.isArray(list)) {
	    throw new TypeError('"list" argument must be an Array of Buffers')
	  }

	  if (list.length === 0) {
	    return Buffer.alloc(0)
	  }

	  let i;
	  if (length === undefined) {
	    length = 0;
	    for (i = 0; i < list.length; ++i) {
	      length += list[i].length;
	    }
	  }

	  const buffer = Buffer.allocUnsafe(length);
	  let pos = 0;
	  for (i = 0; i < list.length; ++i) {
	    let buf = list[i];
	    if (isInstance(buf, GlobalUint8Array)) {
	      if (pos + buf.length > buffer.length) {
	        if (!Buffer.isBuffer(buf)) buf = Buffer.from(buf);
	        buf.copy(buffer, pos);
	      } else {
	        GlobalUint8Array.prototype.set.call(
	          buffer,
	          buf,
	          pos
	        );
	      }
	    } else if (!Buffer.isBuffer(buf)) {
	      throw new TypeError('"list" argument must be an Array of Buffers')
	    } else {
	      buf.copy(buffer, pos);
	    }
	    pos += buf.length;
	  }
	  return buffer
	};

	function byteLength (string, encoding) {
	  if (Buffer.isBuffer(string)) {
	    return string.length
	  }
	  if (GlobalArrayBuffer.isView(string) || isInstance(string, GlobalArrayBuffer)) {
	    return string.byteLength
	  }
	  if (typeof string !== 'string') {
	    throw new TypeError(
	      'The "string" argument must be one of type string, Buffer, or ArrayBuffer. ' +
	      'Received type ' + typeof string
	    )
	  }

	  const len = string.length;
	  const mustMatch = (arguments.length > 2 && arguments[2] === true);
	  if (!mustMatch && len === 0) return 0

	  // Use a for loop to avoid recursion
	  let loweredCase = false;
	  for (;;) {
	    switch (encoding) {
	      case 'ascii':
	      case 'latin1':
	      case 'binary':
	        return len
	      case 'utf8':
	      case 'utf-8':
	        return utf8ToBytes(string).length
	      case 'ucs2':
	      case 'ucs-2':
	      case 'utf16le':
	      case 'utf-16le':
	        return len * 2
	      case 'hex':
	        return len >>> 1
	      case 'base64':
	        return base64ToBytes(string).length
	      default:
	        if (loweredCase) {
	          return mustMatch ? -1 : utf8ToBytes(string).length // assume utf8
	        }
	        encoding = ('' + encoding).toLowerCase();
	        loweredCase = true;
	    }
	  }
	}
	Buffer.byteLength = byteLength;

	function slowToString (encoding, start, end) {
	  let loweredCase = false;

	  // No need to verify that "this.length <= MAX_UINT32" since it's a read-only
	  // property of a typed array.

	  // This behaves neither like String nor Uint8Array in that we set start/end
	  // to their upper/lower bounds if the value passed is out of range.
	  // undefined is handled specially as per ECMA-262 6th Edition,
	  // Section 13.3.3.7 Runtime Semantics: KeyedBindingInitialization.
	  if (start === undefined || start < 0) {
	    start = 0;
	  }
	  // Return early if start > this.length. Done here to prevent potential uint32
	  // coercion fail below.
	  if (start > this.length) {
	    return ''
	  }

	  if (end === undefined || end > this.length) {
	    end = this.length;
	  }

	  if (end <= 0) {
	    return ''
	  }

	  // Force coercion to uint32. This will also coerce falsey/NaN values to 0.
	  end >>>= 0;
	  start >>>= 0;

	  if (end <= start) {
	    return ''
	  }

	  if (!encoding) encoding = 'utf8';

	  while (true) {
	    switch (encoding) {
	      case 'hex':
	        return hexSlice(this, start, end)

	      case 'utf8':
	      case 'utf-8':
	        return utf8Slice(this, start, end)

	      case 'ascii':
	        return asciiSlice(this, start, end)

	      case 'latin1':
	      case 'binary':
	        return latin1Slice(this, start, end)

	      case 'base64':
	        return base64Slice(this, start, end)

	      case 'ucs2':
	      case 'ucs-2':
	      case 'utf16le':
	      case 'utf-16le':
	        return utf16leSlice(this, start, end)

	      default:
	        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
	        encoding = (encoding + '').toLowerCase();
	        loweredCase = true;
	    }
	  }
	}

	// This property is used by `Buffer.isBuffer` (and the `is-buffer` npm package)
	// to detect a Buffer instance. It's not possible to use `instanceof Buffer`
	// reliably in a browserify context because there could be multiple different
	// copies of the 'buffer' package in use. This method works even for Buffer
	// instances that were created from another copy of the `buffer` package.
	// See: https://github.com/feross/buffer/issues/154
	Buffer.prototype._isBuffer = true;

	function swap (b, n, m) {
	  const i = b[n];
	  b[n] = b[m];
	  b[m] = i;
	}

	Buffer.prototype.swap16 = function swap16 () {
	  const len = this.length;
	  if (len % 2 !== 0) {
	    throw new RangeError('Buffer size must be a multiple of 16-bits')
	  }
	  for (let i = 0; i < len; i += 2) {
	    swap(this, i, i + 1);
	  }
	  return this
	};

	Buffer.prototype.swap32 = function swap32 () {
	  const len = this.length;
	  if (len % 4 !== 0) {
	    throw new RangeError('Buffer size must be a multiple of 32-bits')
	  }
	  for (let i = 0; i < len; i += 4) {
	    swap(this, i, i + 3);
	    swap(this, i + 1, i + 2);
	  }
	  return this
	};

	Buffer.prototype.swap64 = function swap64 () {
	  const len = this.length;
	  if (len % 8 !== 0) {
	    throw new RangeError('Buffer size must be a multiple of 64-bits')
	  }
	  for (let i = 0; i < len; i += 8) {
	    swap(this, i, i + 7);
	    swap(this, i + 1, i + 6);
	    swap(this, i + 2, i + 5);
	    swap(this, i + 3, i + 4);
	  }
	  return this
	};

	Buffer.prototype.toString = function toString () {
	  const length = this.length;
	  if (length === 0) return ''
	  if (arguments.length === 0) return utf8Slice(this, 0, length)
	  return slowToString.apply(this, arguments)
	};

	Buffer.prototype.toLocaleString = Buffer.prototype.toString;

	Buffer.prototype.equals = function equals (b) {
	  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
	  if (this === b) return true
	  return Buffer.compare(this, b) === 0
	};

	Buffer.prototype.inspect = function inspect () {
	  let str = '';
	  const max = exports.INSPECT_MAX_BYTES;
	  str = this.toString('hex', 0, max).replace(/(.{2})/g, '$1 ').trim();
	  if (this.length > max) str += ' ... ';
	  return '<Buffer ' + str + '>'
	};
	if (customInspectSymbol) {
	  Buffer.prototype[customInspectSymbol] = Buffer.prototype.inspect;
	}

	Buffer.prototype.compare = function compare (target, start, end, thisStart, thisEnd) {
	  if (isInstance(target, GlobalUint8Array)) {
	    target = Buffer.from(target, target.offset, target.byteLength);
	  }
	  if (!Buffer.isBuffer(target)) {
	    throw new TypeError(
	      'The "target" argument must be one of type Buffer or Uint8Array. ' +
	      'Received type ' + (typeof target)
	    )
	  }

	  if (start === undefined) {
	    start = 0;
	  }
	  if (end === undefined) {
	    end = target ? target.length : 0;
	  }
	  if (thisStart === undefined) {
	    thisStart = 0;
	  }
	  if (thisEnd === undefined) {
	    thisEnd = this.length;
	  }

	  if (start < 0 || end > target.length || thisStart < 0 || thisEnd > this.length) {
	    throw new RangeError('out of range index')
	  }

	  if (thisStart >= thisEnd && start >= end) {
	    return 0
	  }
	  if (thisStart >= thisEnd) {
	    return -1
	  }
	  if (start >= end) {
	    return 1
	  }

	  start >>>= 0;
	  end >>>= 0;
	  thisStart >>>= 0;
	  thisEnd >>>= 0;

	  if (this === target) return 0

	  let x = thisEnd - thisStart;
	  let y = end - start;
	  const len = Math.min(x, y);

	  const thisCopy = this.slice(thisStart, thisEnd);
	  const targetCopy = target.slice(start, end);

	  for (let i = 0; i < len; ++i) {
	    if (thisCopy[i] !== targetCopy[i]) {
	      x = thisCopy[i];
	      y = targetCopy[i];
	      break
	    }
	  }

	  if (x < y) return -1
	  if (y < x) return 1
	  return 0
	};

	// Finds either the first index of `val` in `buffer` at offset >= `byteOffset`,
	// OR the last index of `val` in `buffer` at offset <= `byteOffset`.
	//
	// Arguments:
	// - buffer - a Buffer to search
	// - val - a string, Buffer, or number
	// - byteOffset - an index into `buffer`; will be clamped to an int32
	// - encoding - an optional encoding, relevant is val is a string
	// - dir - true for indexOf, false for lastIndexOf
	function bidirectionalIndexOf (buffer, val, byteOffset, encoding, dir) {
	  // Empty buffer means no match
	  if (buffer.length === 0) return -1

	  // Normalize byteOffset
	  if (typeof byteOffset === 'string') {
	    encoding = byteOffset;
	    byteOffset = 0;
	  } else if (byteOffset > 0x7fffffff) {
	    byteOffset = 0x7fffffff;
	  } else if (byteOffset < -0x80000000) {
	    byteOffset = -0x80000000;
	  }
	  byteOffset = +byteOffset; // Coerce to Number.
	  if (numberIsNaN(byteOffset)) {
	    // byteOffset: it it's undefined, null, NaN, "foo", etc, search whole buffer
	    byteOffset = dir ? 0 : (buffer.length - 1);
	  }

	  // Normalize byteOffset: negative offsets start from the end of the buffer
	  if (byteOffset < 0) byteOffset = buffer.length + byteOffset;
	  if (byteOffset >= buffer.length) {
	    if (dir) return -1
	    else byteOffset = buffer.length - 1;
	  } else if (byteOffset < 0) {
	    if (dir) byteOffset = 0;
	    else return -1
	  }

	  // Normalize val
	  if (typeof val === 'string') {
	    val = Buffer.from(val, encoding);
	  }

	  // Finally, search either indexOf (if dir is true) or lastIndexOf
	  if (Buffer.isBuffer(val)) {
	    // Special case: looking for empty string/buffer always fails
	    if (val.length === 0) {
	      return -1
	    }
	    return arrayIndexOf(buffer, val, byteOffset, encoding, dir)
	  } else if (typeof val === 'number') {
	    val = val & 0xFF; // Search for a byte value [0-255]
	    if (typeof GlobalUint8Array.prototype.indexOf === 'function') {
	      if (dir) {
	        return GlobalUint8Array.prototype.indexOf.call(buffer, val, byteOffset)
	      } else {
	        return GlobalUint8Array.prototype.lastIndexOf.call(buffer, val, byteOffset)
	      }
	    }
	    return arrayIndexOf(buffer, [val], byteOffset, encoding, dir)
	  }

	  throw new TypeError('val must be string, number or Buffer')
	}

	function arrayIndexOf (arr, val, byteOffset, encoding, dir) {
	  let indexSize = 1;
	  let arrLength = arr.length;
	  let valLength = val.length;

	  if (encoding !== undefined) {
	    encoding = String(encoding).toLowerCase();
	    if (encoding === 'ucs2' || encoding === 'ucs-2' ||
	        encoding === 'utf16le' || encoding === 'utf-16le') {
	      if (arr.length < 2 || val.length < 2) {
	        return -1
	      }
	      indexSize = 2;
	      arrLength /= 2;
	      valLength /= 2;
	      byteOffset /= 2;
	    }
	  }

	  function read (buf, i) {
	    if (indexSize === 1) {
	      return buf[i]
	    } else {
	      return buf.readUInt16BE(i * indexSize)
	    }
	  }

	  let i;
	  if (dir) {
	    let foundIndex = -1;
	    for (i = byteOffset; i < arrLength; i++) {
	      if (read(arr, i) === read(val, foundIndex === -1 ? 0 : i - foundIndex)) {
	        if (foundIndex === -1) foundIndex = i;
	        if (i - foundIndex + 1 === valLength) return foundIndex * indexSize
	      } else {
	        if (foundIndex !== -1) i -= i - foundIndex;
	        foundIndex = -1;
	      }
	    }
	  } else {
	    if (byteOffset + valLength > arrLength) byteOffset = arrLength - valLength;
	    for (i = byteOffset; i >= 0; i--) {
	      let found = true;
	      for (let j = 0; j < valLength; j++) {
	        if (read(arr, i + j) !== read(val, j)) {
	          found = false;
	          break
	        }
	      }
	      if (found) return i
	    }
	  }

	  return -1
	}

	Buffer.prototype.includes = function includes (val, byteOffset, encoding) {
	  return this.indexOf(val, byteOffset, encoding) !== -1
	};

	Buffer.prototype.indexOf = function indexOf (val, byteOffset, encoding) {
	  return bidirectionalIndexOf(this, val, byteOffset, encoding, true)
	};

	Buffer.prototype.lastIndexOf = function lastIndexOf (val, byteOffset, encoding) {
	  return bidirectionalIndexOf(this, val, byteOffset, encoding, false)
	};

	function hexWrite (buf, string, offset, length) {
	  offset = Number(offset) || 0;
	  const remaining = buf.length - offset;
	  if (!length) {
	    length = remaining;
	  } else {
	    length = Number(length);
	    if (length > remaining) {
	      length = remaining;
	    }
	  }

	  const strLen = string.length;

	  if (length > strLen / 2) {
	    length = strLen / 2;
	  }
	  let i;
	  for (i = 0; i < length; ++i) {
	    const parsed = parseInt(string.substr(i * 2, 2), 16);
	    if (numberIsNaN(parsed)) return i
	    buf[offset + i] = parsed;
	  }
	  return i
	}

	function utf8Write (buf, string, offset, length) {
	  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
	}

	function asciiWrite (buf, string, offset, length) {
	  return blitBuffer(asciiToBytes(string), buf, offset, length)
	}

	function base64Write (buf, string, offset, length) {
	  return blitBuffer(base64ToBytes(string), buf, offset, length)
	}

	function ucs2Write (buf, string, offset, length) {
	  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
	}

	Buffer.prototype.write = function write (string, offset, length, encoding) {
	  // Buffer#write(string)
	  if (offset === undefined) {
	    encoding = 'utf8';
	    length = this.length;
	    offset = 0;
	  // Buffer#write(string, encoding)
	  } else if (length === undefined && typeof offset === 'string') {
	    encoding = offset;
	    length = this.length;
	    offset = 0;
	  // Buffer#write(string, offset[, length][, encoding])
	  } else if (isFinite(offset)) {
	    offset = offset >>> 0;
	    if (isFinite(length)) {
	      length = length >>> 0;
	      if (encoding === undefined) encoding = 'utf8';
	    } else {
	      encoding = length;
	      length = undefined;
	    }
	  } else {
	    throw new Error(
	      'Buffer.write(string, encoding, offset[, length]) is no longer supported'
	    )
	  }

	  const remaining = this.length - offset;
	  if (length === undefined || length > remaining) length = remaining;

	  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
	    throw new RangeError('Attempt to write outside buffer bounds')
	  }

	  if (!encoding) encoding = 'utf8';

	  let loweredCase = false;
	  for (;;) {
	    switch (encoding) {
	      case 'hex':
	        return hexWrite(this, string, offset, length)

	      case 'utf8':
	      case 'utf-8':
	        return utf8Write(this, string, offset, length)

	      case 'ascii':
	      case 'latin1':
	      case 'binary':
	        return asciiWrite(this, string, offset, length)

	      case 'base64':
	        // Warning: maxLength not taken into account in base64Write
	        return base64Write(this, string, offset, length)

	      case 'ucs2':
	      case 'ucs-2':
	      case 'utf16le':
	      case 'utf-16le':
	        return ucs2Write(this, string, offset, length)

	      default:
	        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
	        encoding = ('' + encoding).toLowerCase();
	        loweredCase = true;
	    }
	  }
	};

	Buffer.prototype.toJSON = function toJSON () {
	  return {
	    type: 'Buffer',
	    data: Array.prototype.slice.call(this._arr || this, 0)
	  }
	};

	function base64Slice (buf, start, end) {
	  if (start === 0 && end === buf.length) {
	    return base64.fromByteArray(buf)
	  } else {
	    return base64.fromByteArray(buf.slice(start, end))
	  }
	}

	function utf8Slice (buf, start, end) {
	  end = Math.min(buf.length, end);
	  const res = [];

	  let i = start;
	  while (i < end) {
	    const firstByte = buf[i];
	    let codePoint = null;
	    let bytesPerSequence = (firstByte > 0xEF)
	      ? 4
	      : (firstByte > 0xDF)
	          ? 3
	          : (firstByte > 0xBF)
	              ? 2
	              : 1;

	    if (i + bytesPerSequence <= end) {
	      let secondByte, thirdByte, fourthByte, tempCodePoint;

	      switch (bytesPerSequence) {
	        case 1:
	          if (firstByte < 0x80) {
	            codePoint = firstByte;
	          }
	          break
	        case 2:
	          secondByte = buf[i + 1];
	          if ((secondByte & 0xC0) === 0x80) {
	            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F);
	            if (tempCodePoint > 0x7F) {
	              codePoint = tempCodePoint;
	            }
	          }
	          break
	        case 3:
	          secondByte = buf[i + 1];
	          thirdByte = buf[i + 2];
	          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
	            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F);
	            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
	              codePoint = tempCodePoint;
	            }
	          }
	          break
	        case 4:
	          secondByte = buf[i + 1];
	          thirdByte = buf[i + 2];
	          fourthByte = buf[i + 3];
	          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
	            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F);
	            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
	              codePoint = tempCodePoint;
	            }
	          }
	      }
	    }

	    if (codePoint === null) {
	      // we did not generate a valid codePoint so insert a
	      // replacement char (U+FFFD) and advance only 1 byte
	      codePoint = 0xFFFD;
	      bytesPerSequence = 1;
	    } else if (codePoint > 0xFFFF) {
	      // encode to utf16 (surrogate pair dance)
	      codePoint -= 0x10000;
	      res.push(codePoint >>> 10 & 0x3FF | 0xD800);
	      codePoint = 0xDC00 | codePoint & 0x3FF;
	    }

	    res.push(codePoint);
	    i += bytesPerSequence;
	  }

	  return decodeCodePointsArray(res)
	}

	// Based on http://stackoverflow.com/a/22747272/680742, the browser with
	// the lowest limit is Chrome, with 0x10000 args.
	// We go 1 magnitude less, for safety
	const MAX_ARGUMENTS_LENGTH = 0x1000;

	function decodeCodePointsArray (codePoints) {
	  const len = codePoints.length;
	  if (len <= MAX_ARGUMENTS_LENGTH) {
	    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
	  }

	  // Decode in chunks to avoid "call stack size exceeded".
	  let res = '';
	  let i = 0;
	  while (i < len) {
	    res += String.fromCharCode.apply(
	      String,
	      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
	    );
	  }
	  return res
	}

	function asciiSlice (buf, start, end) {
	  let ret = '';
	  end = Math.min(buf.length, end);

	  for (let i = start; i < end; ++i) {
	    ret += String.fromCharCode(buf[i] & 0x7F);
	  }
	  return ret
	}

	function latin1Slice (buf, start, end) {
	  let ret = '';
	  end = Math.min(buf.length, end);

	  for (let i = start; i < end; ++i) {
	    ret += String.fromCharCode(buf[i]);
	  }
	  return ret
	}

	function hexSlice (buf, start, end) {
	  const len = buf.length;

	  if (!start || start < 0) start = 0;
	  if (!end || end < 0 || end > len) end = len;

	  let out = '';
	  for (let i = start; i < end; ++i) {
	    out += hexSliceLookupTable[buf[i]];
	  }
	  return out
	}

	function utf16leSlice (buf, start, end) {
	  const bytes = buf.slice(start, end);
	  let res = '';
	  // If bytes.length is odd, the last 8 bits must be ignored (same as node.js)
	  for (let i = 0; i < bytes.length - 1; i += 2) {
	    res += String.fromCharCode(bytes[i] + (bytes[i + 1] * 256));
	  }
	  return res
	}

	Buffer.prototype.slice = function slice (start, end) {
	  const len = this.length;
	  start = ~~start;
	  end = end === undefined ? len : ~~end;

	  if (start < 0) {
	    start += len;
	    if (start < 0) start = 0;
	  } else if (start > len) {
	    start = len;
	  }

	  if (end < 0) {
	    end += len;
	    if (end < 0) end = 0;
	  } else if (end > len) {
	    end = len;
	  }

	  if (end < start) end = start;

	  const newBuf = this.subarray(start, end);
	  // Return an augmented `Uint8Array` instance
	  Object.setPrototypeOf(newBuf, Buffer.prototype);

	  return newBuf
	};

	/*
	 * Need to make sure that buffer isn't trying to write out of bounds.
	 */
	function checkOffset (offset, ext, length) {
	  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
	  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
	}

	Buffer.prototype.readUintLE =
	Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
	  offset = offset >>> 0;
	  byteLength = byteLength >>> 0;
	  if (!noAssert) checkOffset(offset, byteLength, this.length);

	  let val = this[offset];
	  let mul = 1;
	  let i = 0;
	  while (++i < byteLength && (mul *= 0x100)) {
	    val += this[offset + i] * mul;
	  }

	  return val
	};

	Buffer.prototype.readUintBE =
	Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
	  offset = offset >>> 0;
	  byteLength = byteLength >>> 0;
	  if (!noAssert) {
	    checkOffset(offset, byteLength, this.length);
	  }

	  let val = this[offset + --byteLength];
	  let mul = 1;
	  while (byteLength > 0 && (mul *= 0x100)) {
	    val += this[offset + --byteLength] * mul;
	  }

	  return val
	};

	Buffer.prototype.readUint8 =
	Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 1, this.length);
	  return this[offset]
	};

	Buffer.prototype.readUint16LE =
	Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 2, this.length);
	  return this[offset] | (this[offset + 1] << 8)
	};

	Buffer.prototype.readUint16BE =
	Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 2, this.length);
	  return (this[offset] << 8) | this[offset + 1]
	};

	Buffer.prototype.readUint32LE =
	Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 4, this.length);

	  return ((this[offset]) |
	      (this[offset + 1] << 8) |
	      (this[offset + 2] << 16)) +
	      (this[offset + 3] * 0x1000000)
	};

	Buffer.prototype.readUint32BE =
	Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 4, this.length);

	  return (this[offset] * 0x1000000) +
	    ((this[offset + 1] << 16) |
	    (this[offset + 2] << 8) |
	    this[offset + 3])
	};

	Buffer.prototype.readBigUInt64LE = defineBigIntMethod(function readBigUInt64LE (offset) {
	  offset = offset >>> 0;
	  validateNumber(offset, 'offset');
	  const first = this[offset];
	  const last = this[offset + 7];
	  if (first === undefined || last === undefined) {
	    boundsError(offset, this.length - 8);
	  }

	  const lo = first +
	    this[++offset] * 2 ** 8 +
	    this[++offset] * 2 ** 16 +
	    this[++offset] * 2 ** 24;

	  const hi = this[++offset] +
	    this[++offset] * 2 ** 8 +
	    this[++offset] * 2 ** 16 +
	    last * 2 ** 24;

	  return BigInt(lo) + (BigInt(hi) << BigInt(32))
	});

	Buffer.prototype.readBigUInt64BE = defineBigIntMethod(function readBigUInt64BE (offset) {
	  offset = offset >>> 0;
	  validateNumber(offset, 'offset');
	  const first = this[offset];
	  const last = this[offset + 7];
	  if (first === undefined || last === undefined) {
	    boundsError(offset, this.length - 8);
	  }

	  const hi = first * 2 ** 24 +
	    this[++offset] * 2 ** 16 +
	    this[++offset] * 2 ** 8 +
	    this[++offset];

	  const lo = this[++offset] * 2 ** 24 +
	    this[++offset] * 2 ** 16 +
	    this[++offset] * 2 ** 8 +
	    last;

	  return (BigInt(hi) << BigInt(32)) + BigInt(lo)
	});

	Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
	  offset = offset >>> 0;
	  byteLength = byteLength >>> 0;
	  if (!noAssert) checkOffset(offset, byteLength, this.length);

	  let val = this[offset];
	  let mul = 1;
	  let i = 0;
	  while (++i < byteLength && (mul *= 0x100)) {
	    val += this[offset + i] * mul;
	  }
	  mul *= 0x80;

	  if (val >= mul) val -= Math.pow(2, 8 * byteLength);

	  return val
	};

	Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
	  offset = offset >>> 0;
	  byteLength = byteLength >>> 0;
	  if (!noAssert) checkOffset(offset, byteLength, this.length);

	  let i = byteLength;
	  let mul = 1;
	  let val = this[offset + --i];
	  while (i > 0 && (mul *= 0x100)) {
	    val += this[offset + --i] * mul;
	  }
	  mul *= 0x80;

	  if (val >= mul) val -= Math.pow(2, 8 * byteLength);

	  return val
	};

	Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 1, this.length);
	  if (!(this[offset] & 0x80)) return (this[offset])
	  return ((0xff - this[offset] + 1) * -1)
	};

	Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 2, this.length);
	  const val = this[offset] | (this[offset + 1] << 8);
	  return (val & 0x8000) ? val | 0xFFFF0000 : val
	};

	Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 2, this.length);
	  const val = this[offset + 1] | (this[offset] << 8);
	  return (val & 0x8000) ? val | 0xFFFF0000 : val
	};

	Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 4, this.length);

	  return (this[offset]) |
	    (this[offset + 1] << 8) |
	    (this[offset + 2] << 16) |
	    (this[offset + 3] << 24)
	};

	Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 4, this.length);

	  return (this[offset] << 24) |
	    (this[offset + 1] << 16) |
	    (this[offset + 2] << 8) |
	    (this[offset + 3])
	};

	Buffer.prototype.readBigInt64LE = defineBigIntMethod(function readBigInt64LE (offset) {
	  offset = offset >>> 0;
	  validateNumber(offset, 'offset');
	  const first = this[offset];
	  const last = this[offset + 7];
	  if (first === undefined || last === undefined) {
	    boundsError(offset, this.length - 8);
	  }

	  const val = this[offset + 4] +
	    this[offset + 5] * 2 ** 8 +
	    this[offset + 6] * 2 ** 16 +
	    (last << 24); // Overflow

	  return (BigInt(val) << BigInt(32)) +
	    BigInt(first +
	    this[++offset] * 2 ** 8 +
	    this[++offset] * 2 ** 16 +
	    this[++offset] * 2 ** 24)
	});

	Buffer.prototype.readBigInt64BE = defineBigIntMethod(function readBigInt64BE (offset) {
	  offset = offset >>> 0;
	  validateNumber(offset, 'offset');
	  const first = this[offset];
	  const last = this[offset + 7];
	  if (first === undefined || last === undefined) {
	    boundsError(offset, this.length - 8);
	  }

	  const val = (first << 24) + // Overflow
	    this[++offset] * 2 ** 16 +
	    this[++offset] * 2 ** 8 +
	    this[++offset];

	  return (BigInt(val) << BigInt(32)) +
	    BigInt(this[++offset] * 2 ** 24 +
	    this[++offset] * 2 ** 16 +
	    this[++offset] * 2 ** 8 +
	    last)
	});

	Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 4, this.length);
	  return ieee754$1.read(this, offset, true, 23, 4)
	};

	Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 4, this.length);
	  return ieee754$1.read(this, offset, false, 23, 4)
	};

	Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 8, this.length);
	  return ieee754$1.read(this, offset, true, 52, 8)
	};

	Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
	  offset = offset >>> 0;
	  if (!noAssert) checkOffset(offset, 8, this.length);
	  return ieee754$1.read(this, offset, false, 52, 8)
	};

	function checkInt (buf, value, offset, ext, max, min) {
	  if (!Buffer.isBuffer(buf)) throw new TypeError('"buffer" argument must be a Buffer instance')
	  if (value > max || value < min) throw new RangeError('"value" argument is out of bounds')
	  if (offset + ext > buf.length) throw new RangeError('Index out of range')
	}

	Buffer.prototype.writeUintLE =
	Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  byteLength = byteLength >>> 0;
	  if (!noAssert) {
	    const maxBytes = Math.pow(2, 8 * byteLength) - 1;
	    checkInt(this, value, offset, byteLength, maxBytes, 0);
	  }

	  let mul = 1;
	  let i = 0;
	  this[offset] = value & 0xFF;
	  while (++i < byteLength && (mul *= 0x100)) {
	    this[offset + i] = (value / mul) & 0xFF;
	  }

	  return offset + byteLength
	};

	Buffer.prototype.writeUintBE =
	Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  byteLength = byteLength >>> 0;
	  if (!noAssert) {
	    const maxBytes = Math.pow(2, 8 * byteLength) - 1;
	    checkInt(this, value, offset, byteLength, maxBytes, 0);
	  }

	  let i = byteLength - 1;
	  let mul = 1;
	  this[offset + i] = value & 0xFF;
	  while (--i >= 0 && (mul *= 0x100)) {
	    this[offset + i] = (value / mul) & 0xFF;
	  }

	  return offset + byteLength
	};

	Buffer.prototype.writeUint8 =
	Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0);
	  this[offset] = (value & 0xff);
	  return offset + 1
	};

	Buffer.prototype.writeUint16LE =
	Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
	  this[offset] = (value & 0xff);
	  this[offset + 1] = (value >>> 8);
	  return offset + 2
	};

	Buffer.prototype.writeUint16BE =
	Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0);
	  this[offset] = (value >>> 8);
	  this[offset + 1] = (value & 0xff);
	  return offset + 2
	};

	Buffer.prototype.writeUint32LE =
	Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
	  this[offset + 3] = (value >>> 24);
	  this[offset + 2] = (value >>> 16);
	  this[offset + 1] = (value >>> 8);
	  this[offset] = (value & 0xff);
	  return offset + 4
	};

	Buffer.prototype.writeUint32BE =
	Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0);
	  this[offset] = (value >>> 24);
	  this[offset + 1] = (value >>> 16);
	  this[offset + 2] = (value >>> 8);
	  this[offset + 3] = (value & 0xff);
	  return offset + 4
	};

	function wrtBigUInt64LE (buf, value, offset, min, max) {
	  checkIntBI(value, min, max, buf, offset, 7);

	  let lo = Number(value & BigInt(0xffffffff));
	  buf[offset++] = lo;
	  lo = lo >> 8;
	  buf[offset++] = lo;
	  lo = lo >> 8;
	  buf[offset++] = lo;
	  lo = lo >> 8;
	  buf[offset++] = lo;
	  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff));
	  buf[offset++] = hi;
	  hi = hi >> 8;
	  buf[offset++] = hi;
	  hi = hi >> 8;
	  buf[offset++] = hi;
	  hi = hi >> 8;
	  buf[offset++] = hi;
	  return offset
	}

	function wrtBigUInt64BE (buf, value, offset, min, max) {
	  checkIntBI(value, min, max, buf, offset, 7);

	  let lo = Number(value & BigInt(0xffffffff));
	  buf[offset + 7] = lo;
	  lo = lo >> 8;
	  buf[offset + 6] = lo;
	  lo = lo >> 8;
	  buf[offset + 5] = lo;
	  lo = lo >> 8;
	  buf[offset + 4] = lo;
	  let hi = Number(value >> BigInt(32) & BigInt(0xffffffff));
	  buf[offset + 3] = hi;
	  hi = hi >> 8;
	  buf[offset + 2] = hi;
	  hi = hi >> 8;
	  buf[offset + 1] = hi;
	  hi = hi >> 8;
	  buf[offset] = hi;
	  return offset + 8
	}

	Buffer.prototype.writeBigUInt64LE = defineBigIntMethod(function writeBigUInt64LE (value, offset = 0) {
	  return wrtBigUInt64LE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
	});

	Buffer.prototype.writeBigUInt64BE = defineBigIntMethod(function writeBigUInt64BE (value, offset = 0) {
	  return wrtBigUInt64BE(this, value, offset, BigInt(0), BigInt('0xffffffffffffffff'))
	});

	Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) {
	    const limit = Math.pow(2, (8 * byteLength) - 1);

	    checkInt(this, value, offset, byteLength, limit - 1, -limit);
	  }

	  let i = 0;
	  let mul = 1;
	  let sub = 0;
	  this[offset] = value & 0xFF;
	  while (++i < byteLength && (mul *= 0x100)) {
	    if (value < 0 && sub === 0 && this[offset + i - 1] !== 0) {
	      sub = 1;
	    }
	    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF;
	  }

	  return offset + byteLength
	};

	Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) {
	    const limit = Math.pow(2, (8 * byteLength) - 1);

	    checkInt(this, value, offset, byteLength, limit - 1, -limit);
	  }

	  let i = byteLength - 1;
	  let mul = 1;
	  let sub = 0;
	  this[offset + i] = value & 0xFF;
	  while (--i >= 0 && (mul *= 0x100)) {
	    if (value < 0 && sub === 0 && this[offset + i + 1] !== 0) {
	      sub = 1;
	    }
	    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF;
	  }

	  return offset + byteLength
	};

	Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80);
	  if (value < 0) value = 0xff + value + 1;
	  this[offset] = (value & 0xff);
	  return offset + 1
	};

	Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000);
	  this[offset] = (value & 0xff);
	  this[offset + 1] = (value >>> 8);
	  return offset + 2
	};

	Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000);
	  this[offset] = (value >>> 8);
	  this[offset + 1] = (value & 0xff);
	  return offset + 2
	};

	Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000);
	  this[offset] = (value & 0xff);
	  this[offset + 1] = (value >>> 8);
	  this[offset + 2] = (value >>> 16);
	  this[offset + 3] = (value >>> 24);
	  return offset + 4
	};

	Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000);
	  if (value < 0) value = 0xffffffff + value + 1;
	  this[offset] = (value >>> 24);
	  this[offset + 1] = (value >>> 16);
	  this[offset + 2] = (value >>> 8);
	  this[offset + 3] = (value & 0xff);
	  return offset + 4
	};

	Buffer.prototype.writeBigInt64LE = defineBigIntMethod(function writeBigInt64LE (value, offset = 0) {
	  return wrtBigUInt64LE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
	});

	Buffer.prototype.writeBigInt64BE = defineBigIntMethod(function writeBigInt64BE (value, offset = 0) {
	  return wrtBigUInt64BE(this, value, offset, -BigInt('0x8000000000000000'), BigInt('0x7fffffffffffffff'))
	});

	function checkIEEE754 (buf, value, offset, ext, max, min) {
	  if (offset + ext > buf.length) throw new RangeError('Index out of range')
	  if (offset < 0) throw new RangeError('Index out of range')
	}

	function writeFloat (buf, value, offset, littleEndian, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) {
	    checkIEEE754(buf, value, offset, 4);
	  }
	  ieee754$1.write(buf, value, offset, littleEndian, 23, 4);
	  return offset + 4
	}

	Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
	  return writeFloat(this, value, offset, true, noAssert)
	};

	Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
	  return writeFloat(this, value, offset, false, noAssert)
	};

	function writeDouble (buf, value, offset, littleEndian, noAssert) {
	  value = +value;
	  offset = offset >>> 0;
	  if (!noAssert) {
	    checkIEEE754(buf, value, offset, 8);
	  }
	  ieee754$1.write(buf, value, offset, littleEndian, 52, 8);
	  return offset + 8
	}

	Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
	  return writeDouble(this, value, offset, true, noAssert)
	};

	Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
	  return writeDouble(this, value, offset, false, noAssert)
	};

	// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
	Buffer.prototype.copy = function copy (target, targetStart, start, end) {
	  if (!Buffer.isBuffer(target)) throw new TypeError('argument should be a Buffer')
	  if (!start) start = 0;
	  if (!end && end !== 0) end = this.length;
	  if (targetStart >= target.length) targetStart = target.length;
	  if (!targetStart) targetStart = 0;
	  if (end > 0 && end < start) end = start;

	  // Copy 0 bytes; we're done
	  if (end === start) return 0
	  if (target.length === 0 || this.length === 0) return 0

	  // Fatal error conditions
	  if (targetStart < 0) {
	    throw new RangeError('targetStart out of bounds')
	  }
	  if (start < 0 || start >= this.length) throw new RangeError('Index out of range')
	  if (end < 0) throw new RangeError('sourceEnd out of bounds')

	  // Are we oob?
	  if (end > this.length) end = this.length;
	  if (target.length - targetStart < end - start) {
	    end = target.length - targetStart + start;
	  }

	  const len = end - start;

	  if (this === target && typeof GlobalUint8Array.prototype.copyWithin === 'function') {
	    // Use built-in when available, missing from IE11
	    this.copyWithin(targetStart, start, end);
	  } else {
	    GlobalUint8Array.prototype.set.call(
	      target,
	      this.subarray(start, end),
	      targetStart
	    );
	  }

	  return len
	};

	// Usage:
	//    buffer.fill(number[, offset[, end]])
	//    buffer.fill(buffer[, offset[, end]])
	//    buffer.fill(string[, offset[, end]][, encoding])
	Buffer.prototype.fill = function fill (val, start, end, encoding) {
	  // Handle string cases:
	  if (typeof val === 'string') {
	    if (typeof start === 'string') {
	      encoding = start;
	      start = 0;
	      end = this.length;
	    } else if (typeof end === 'string') {
	      encoding = end;
	      end = this.length;
	    }
	    if (encoding !== undefined && typeof encoding !== 'string') {
	      throw new TypeError('encoding must be a string')
	    }
	    if (typeof encoding === 'string' && !Buffer.isEncoding(encoding)) {
	      throw new TypeError('Unknown encoding: ' + encoding)
	    }
	    if (val.length === 1) {
	      const code = val.charCodeAt(0);
	      if ((encoding === 'utf8' && code < 128) ||
	          encoding === 'latin1') {
	        // Fast path: If `val` fits into a single byte, use that numeric value.
	        val = code;
	      }
	    }
	  } else if (typeof val === 'number') {
	    val = val & 255;
	  } else if (typeof val === 'boolean') {
	    val = Number(val);
	  }

	  // Invalid ranges are not set to a default, so can range check early.
	  if (start < 0 || this.length < start || this.length < end) {
	    throw new RangeError('Out of range index')
	  }

	  if (end <= start) {
	    return this
	  }

	  start = start >>> 0;
	  end = end === undefined ? this.length : end >>> 0;

	  if (!val) val = 0;

	  let i;
	  if (typeof val === 'number') {
	    for (i = start; i < end; ++i) {
	      this[i] = val;
	    }
	  } else {
	    const bytes = Buffer.isBuffer(val)
	      ? val
	      : Buffer.from(val, encoding);
	    const len = bytes.length;
	    if (len === 0) {
	      throw new TypeError('The value "' + val +
	        '" is invalid for argument "value"')
	    }
	    for (i = 0; i < end - start; ++i) {
	      this[i + start] = bytes[i % len];
	    }
	  }

	  return this
	};

	// CUSTOM ERRORS
	// =============

	// Simplified versions from Node, changed for Buffer-only usage
	const errors = {};
	function E (sym, getMessage, Base) {
	  errors[sym] = class NodeError extends Base {
	    constructor () {
	      super();

	      Object.defineProperty(this, 'message', {
	        value: getMessage.apply(this, arguments),
	        writable: true,
	        configurable: true
	      });

	      // Add the error code to the name to include it in the stack trace.
	      this.name = `${this.name} [${sym}]`;
	      // Access the stack to generate the error message including the error code
	      // from the name.
	      this.stack; // eslint-disable-line no-unused-expressions
	      // Reset the name to the actual name.
	      delete this.name;
	    }

	    get code () {
	      return sym
	    }

	    set code (value) {
	      Object.defineProperty(this, 'code', {
	        configurable: true,
	        enumerable: true,
	        value,
	        writable: true
	      });
	    }

	    toString () {
	      return `${this.name} [${sym}]: ${this.message}`
	    }
	  };
	}

	E('ERR_BUFFER_OUT_OF_BOUNDS',
	  function (name) {
	    if (name) {
	      return `${name} is outside of buffer bounds`
	    }

	    return 'Attempt to access memory outside buffer bounds'
	  }, RangeError);
	E('ERR_INVALID_ARG_TYPE',
	  function (name, actual) {
	    return `The "${name}" argument must be of type number. Received type ${typeof actual}`
	  }, TypeError);
	E('ERR_OUT_OF_RANGE',
	  function (str, range, input) {
	    let msg = `The value of "${str}" is out of range.`;
	    let received = input;
	    if (Number.isInteger(input) && Math.abs(input) > 2 ** 32) {
	      received = addNumericalSeparator(String(input));
	    } else if (typeof input === 'bigint') {
	      received = String(input);
	      if (input > BigInt(2) ** BigInt(32) || input < -(BigInt(2) ** BigInt(32))) {
	        received = addNumericalSeparator(received);
	      }
	      received += 'n';
	    }
	    msg += ` It must be ${range}. Received ${received}`;
	    return msg
	  }, RangeError);

	function addNumericalSeparator (val) {
	  let res = '';
	  let i = val.length;
	  const start = val[0] === '-' ? 1 : 0;
	  for (; i >= start + 4; i -= 3) {
	    res = `_${val.slice(i - 3, i)}${res}`;
	  }
	  return `${val.slice(0, i)}${res}`
	}

	// CHECK FUNCTIONS
	// ===============

	function checkBounds (buf, offset, byteLength) {
	  validateNumber(offset, 'offset');
	  if (buf[offset] === undefined || buf[offset + byteLength] === undefined) {
	    boundsError(offset, buf.length - (byteLength + 1));
	  }
	}

	function checkIntBI (value, min, max, buf, offset, byteLength) {
	  if (value > max || value < min) {
	    const n = typeof min === 'bigint' ? 'n' : '';
	    let range;
	    if (byteLength > 3) {
	      if (min === 0 || min === BigInt(0)) {
	        range = `>= 0${n} and < 2${n} ** ${(byteLength + 1) * 8}${n}`;
	      } else {
	        range = `>= -(2${n} ** ${(byteLength + 1) * 8 - 1}${n}) and < 2 ** ` +
	                `${(byteLength + 1) * 8 - 1}${n}`;
	      }
	    } else {
	      range = `>= ${min}${n} and <= ${max}${n}`;
	    }
	    throw new errors.ERR_OUT_OF_RANGE('value', range, value)
	  }
	  checkBounds(buf, offset, byteLength);
	}

	function validateNumber (value, name) {
	  if (typeof value !== 'number') {
	    throw new errors.ERR_INVALID_ARG_TYPE(name, 'number', value)
	  }
	}

	function boundsError (value, length, type) {
	  if (Math.floor(value) !== value) {
	    validateNumber(value, type);
	    throw new errors.ERR_OUT_OF_RANGE(type || 'offset', 'an integer', value)
	  }

	  if (length < 0) {
	    throw new errors.ERR_BUFFER_OUT_OF_BOUNDS()
	  }

	  throw new errors.ERR_OUT_OF_RANGE(type || 'offset',
	                                    `>= ${type ? 1 : 0} and <= ${length}`,
	                                    value)
	}

	// HELPER FUNCTIONS
	// ================

	const INVALID_BASE64_RE = /[^+/0-9A-Za-z-_]/g;

	function base64clean (str) {
	  // Node takes equal signs as end of the Base64 encoding
	  str = str.split('=')[0];
	  // Node strips out invalid characters like \n and \t from the string, base64-js does not
	  str = str.trim().replace(INVALID_BASE64_RE, '');
	  // Node converts strings with length < 2 to ''
	  if (str.length < 2) return ''
	  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
	  while (str.length % 4 !== 0) {
	    str = str + '=';
	  }
	  return str
	}

	function utf8ToBytes (string, units) {
	  units = units || Infinity;
	  let codePoint;
	  const length = string.length;
	  let leadSurrogate = null;
	  const bytes = [];

	  for (let i = 0; i < length; ++i) {
	    codePoint = string.charCodeAt(i);

	    // is surrogate component
	    if (codePoint > 0xD7FF && codePoint < 0xE000) {
	      // last char was a lead
	      if (!leadSurrogate) {
	        // no lead yet
	        if (codePoint > 0xDBFF) {
	          // unexpected trail
	          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
	          continue
	        } else if (i + 1 === length) {
	          // unpaired lead
	          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
	          continue
	        }

	        // valid lead
	        leadSurrogate = codePoint;

	        continue
	      }

	      // 2 leads in a row
	      if (codePoint < 0xDC00) {
	        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
	        leadSurrogate = codePoint;
	        continue
	      }

	      // valid surrogate pair
	      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000;
	    } else if (leadSurrogate) {
	      // valid bmp char, but last char was a lead
	      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD);
	    }

	    leadSurrogate = null;

	    // encode utf8
	    if (codePoint < 0x80) {
	      if ((units -= 1) < 0) break
	      bytes.push(codePoint);
	    } else if (codePoint < 0x800) {
	      if ((units -= 2) < 0) break
	      bytes.push(
	        codePoint >> 0x6 | 0xC0,
	        codePoint & 0x3F | 0x80
	      );
	    } else if (codePoint < 0x10000) {
	      if ((units -= 3) < 0) break
	      bytes.push(
	        codePoint >> 0xC | 0xE0,
	        codePoint >> 0x6 & 0x3F | 0x80,
	        codePoint & 0x3F | 0x80
	      );
	    } else if (codePoint < 0x110000) {
	      if ((units -= 4) < 0) break
	      bytes.push(
	        codePoint >> 0x12 | 0xF0,
	        codePoint >> 0xC & 0x3F | 0x80,
	        codePoint >> 0x6 & 0x3F | 0x80,
	        codePoint & 0x3F | 0x80
	      );
	    } else {
	      throw new Error('Invalid code point')
	    }
	  }

	  return bytes
	}

	function asciiToBytes (str) {
	  const byteArray = [];
	  for (let i = 0; i < str.length; ++i) {
	    // Node's code seems to be doing this and not & 0x7F..
	    byteArray.push(str.charCodeAt(i) & 0xFF);
	  }
	  return byteArray
	}

	function utf16leToBytes (str, units) {
	  let c, hi, lo;
	  const byteArray = [];
	  for (let i = 0; i < str.length; ++i) {
	    if ((units -= 2) < 0) break

	    c = str.charCodeAt(i);
	    hi = c >> 8;
	    lo = c % 256;
	    byteArray.push(lo);
	    byteArray.push(hi);
	  }

	  return byteArray
	}

	function base64ToBytes (str) {
	  return base64.toByteArray(base64clean(str))
	}

	function blitBuffer (src, dst, offset, length) {
	  let i;
	  for (i = 0; i < length; ++i) {
	    if ((i + offset >= dst.length) || (i >= src.length)) break
	    dst[i + offset] = src[i];
	  }
	  return i
	}

	// ArrayBuffer or Uint8Array objects from other contexts (i.e. iframes) do not pass
	// the `instanceof` check but they should be treated as of that type.
	// See: https://github.com/feross/buffer/issues/166
	function isInstance (obj, type) {
	  return obj instanceof type ||
	    (obj != null && obj.constructor != null && obj.constructor.name != null &&
	      obj.constructor.name === type.name)
	}
	function numberIsNaN (obj) {
	  // For IE11 support
	  return obj !== obj // eslint-disable-line no-self-compare
	}

	// Create lookup table for `toString('hex')`
	// See: https://github.com/feross/buffer/issues/219
	const hexSliceLookupTable = (function () {
	  const alphabet = '0123456789abcdef';
	  const table = new Array(256);
	  for (let i = 0; i < 16; ++i) {
	    const i16 = i * 16;
	    for (let j = 0; j < 16; ++j) {
	      table[i16 + j] = alphabet[i] + alphabet[j];
	    }
	  }
	  return table
	})();

	// Return not function with Error if BigInt not supported
	function defineBigIntMethod (fn) {
	  return typeof BigInt === 'undefined' ? BufferBigIntNotDefined : fn
	}

	function BufferBigIntNotDefined () {
	  throw new Error('BigInt not supported')
	} 
} (buffer));

const Buffer = buffer.Buffer;

const container = {
	display: "flex",
	outline: "none",
	gap: "0px",
	"flex-direction": "row",
	width: "fit-content",
	height: "fit-content",
	"border-style": "solid",
	"border-width": "0px",
	"padding-top": "0px",
	"padding-right": "0px",
	"padding-bottom": "0px",
	"padding-left": "0px",
	opacity: "100",
	"background-color": "transparent",
	"box-sizing": "border-box",
	"border-radius": "0px",
	"flex-shrink": "initial"
};
const input = {
	"border-style": "solid",
	"border-width": "0px"
};
const text = {
	display: "inline",
	"text-align": "start",
	"text-decoration": "none"
};
const icon = {
	display: "flex"
};
const loader = {
	display: "inline-block"
};
const image = {
	display: "block",
	width: "100%"
};
const slot = {
	display: "flex"
};
const layerDefaults = {
	container: container,
	input: input,
	text: text,
	icon: icon,
	loader: loader,
	image: image,
	slot: slot
};

const layerDefaults$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	container,
	default: layerDefaults,
	icon,
	image,
	input,
	loader,
	slot,
	text
}, Symbol.toStringTag, { value: 'Module' }));

const prefixMap = {
  "background-color": "bg",
  color: "text",
  "border-color": "stroke"
};
const colorClassRuleHandler = (rule, ruleVal, tokens) => {
  if (!BrandStore.brandResolverFn) {
    return;
  }
  if (typeof ruleVal === "object") {
    console.warn("Object values are not supported");
    return;
  }
  const resolved = BrandStore.brandResolverFn(rule, ruleVal, tokens, false);
  const prefix = prefixMap[rule];
  if (resolved?.value === "transparent") {
    return `${prefix}-transparent`;
  }
  const scale = resolved?.key?.split(".")[1];
  if (scale) {
    const klass = `${prefix}-${tokens["appearance"]}-${scale}`;
    return klass;
  }
  return void 0;
};
const CLASS_RULE_MAP = {
  "background-color": colorClassRuleHandler,
  color: colorClassRuleHandler,
  "border-color": colorClassRuleHandler,
  "font-size": () => null,
  "line-height": () => null,
  "letter-spacing": () => null,
  "font-weight": () => null
};

const defaults = layerDefaults$1;
const tokenSuffixShortKey = {
  default: "d",
  hover: "h",
  focus: "f",
  active: "a",
  visited: "v"
};
const tokenRuleShortKey = {
  "align-items": "al-it",
  "aspect-ratio": "as-rt",
  "background-color": "bg-cl",
  "blur-radius": "bl-rd",
  "border-color": "br-cl",
  "border-radius": "br-rd",
  "border-style": "br-st",
  "border-width": "br-wd",
  "border-top-width": "brt-wd",
  "border-right-width": "brr-wd",
  "border-bottom-width": "brb-wd",
  "border-left-width": "brl-w",
  "border-top-color": "brt-cl",
  "border-right-color": "brr-cl",
  "border-bottom-color": "brb-cl",
  "border-left-color": "brl-cl",
  "border-top-left-radius": "brtl-r",
  "border-top-right-radius": "brtr-r",
  "border-bottom-right-radius": "brbr-r",
  "border-bottom-left-radius": "brbl-r",
  bottom: "bt",
  "box-shadow": "bx-sh",
  "box-sizing": "bx-sz",
  color: "cl",
  cursor: "cur",
  display: "dis",
  flex: "fx",
  "flex-direction": "fx-dr",
  "font-family": "fo-fm",
  "font-size": "fo-sz",
  "font-weight": "fo-wt",
  gap: "gp",
  height: "ht",
  "justify-content": "js-ct",
  left: "lt",
  "letter-spacing": "lt-sp",
  "line-height": "ln-ht",
  "max-height": "mx-ht",
  "max-width": "mx-wd",
  "min-height": "mn-ht",
  "min-width": "mn-wd",
  opacity: "op",
  outline: "ol",
  overflow: "ov",
  "padding-bottom": "pd-b",
  "padding-left": "pd-l",
  "padding-right": "pd-r",
  "padding-top": "pd-t",
  "pointer-events": "pe",
  position: "pos",
  right: "rt",
  rotate: "rot",
  "text-align": "tx-al",
  "text-decoration": "tx-dc",
  "text-overflow": "tx-ol",
  "text-transform": "tx-tf",
  "object-fit": "oj-ft",
  "object-position": "oj-ps",
  size: "sz",
  up: "up",
  width: "wd",
  "z-index": "zi"
};
function getLayerType(layerName) {
  return layerName.split("-").pop();
}
function getLayerTestId(componentName, layerName) {
  return `${componentName}-${layerName}`;
}
function getRoot(hierarchy) {
  const root = hierarchy;
  if (typeof root === "object") {
    return Object.keys(root)[0];
  }
  return "";
}
function getAllLayers(hierarchy) {
  if (typeof hierarchy === "string") {
    return [hierarchy];
  }
  const root = getRoot(hierarchy);
  const layers = [root];
  const children = hierarchy[root] ?? [];
  for (const child of children) {
    layers.push(...getAllLayers(child));
  }
  return layers;
}
function getInvariants(json) {
  const base = deepClone(json.base);
  for (const prop in json.variant) {
    const propObj = json.variant[prop];
    for (const key in propObj) {
      const variant = propObj[key];
      for (const layer in variant) {
        base[layer] = handleInvariantBaseMap(base[layer], variant[layer]);
      }
    }
  }
  for (const layer in json.api.data || {}) {
    for (const apiItem of Object.keys(json.api.data?.[layer] || {})) {
      if (base[layer]?.[apiItem])
        delete base[layer][apiItem];
    }
  }
  const combinations = getAllCombinations({}, json);
  for (const layer in combinations) {
    base[layer] = handleInvariantBaseMap(base[layer], combinations[layer]);
  }
  for (const layer in base) {
    for (const key in base[layer]) {
      const value = base[layer][key];
      if (String(value).includes("&color"))
        delete base[layer][key];
    }
  }
  return base;
}
function handleInvariantBaseMap(baseItem, variantItem) {
  const { behavior: variantBehavior, ...variantBaseMap } = variantItem;
  if (!baseItem) {
    return baseItem;
  }
  const { behavior, ...baseMap } = baseItem;
  baseItem = removeVariantProps(baseMap, variantBaseMap);
  if (!behavior || !variantBehavior) {
    return behavior ? { ...baseItem, behavior } : baseItem;
  }
  for (const pseudo in variantBehavior) {
    const pseudoBaseMap = behavior?.[pseudo];
    if (!pseudoBaseMap) {
      continue;
    }
    const pseudoVariantBaseMap = variantBehavior[pseudo];
    behavior[pseudo] = removeVariantProps(pseudoBaseMap, pseudoVariantBaseMap);
  }
  return behavior ? { ...baseItem, behavior } : baseItem;
}
function removeVariantProps(baseMap, variantBaseMap) {
  if (!baseMap) {
    return baseMap;
  }
  for (const property in variantBaseMap) {
    const value = variantBaseMap[property];
    if (typeof value === "object" && !Array.isArray(value)) {
      baseMap[property] = removeVariantProps(
        baseMap[property],
        value
      );
      continue;
    }
    if (property in baseMap) {
      delete baseMap[property];
    }
  }
  function handleObject(baseMap2) {
    for (const property in baseMap2) {
      const value = baseMap2[property];
      if (!value) {
        continue;
      }
      if (typeof value === "string") {
        if (value.includes("&") || value.includes("%")) {
          delete baseMap2[property];
        }
      } else if (typeof value === "object" && !Array.isArray(value)) {
        handleObject(value);
      }
    }
  }
  handleObject(baseMap);
  return baseMap;
}
const getLayerClass = (componentName, layer) => `j-${componentName}-${layer}`;
const getBaseCssVariable = (componentName, layer, rule, includeComponentName) => {
  const shortRule = tokenRuleShortKey[rule] || rule;
  const layerKey = getLayerType(layer);
  if (!includeComponentName || layerKey !== "container") {
    return `--${layer}-${shortRule}`;
  }
  return `--${componentName.toLowerCase()}--${layer}-${shortRule}`;
};
const getCssVariable = (componentName, layer, rule, includeComponentName, pseudo) => {
  const cssVar = getBaseCssVariable(componentName, layer, rule, includeComponentName);
  if (pseudo) {
    return `${cssVar}-${tokenSuffixShortKey[pseudo] || pseudo}`;
  }
  return cssVar;
};
const getBaseStyleRule = (componentName, layer, rule, value, isInvariant, pseudo, tokens) => {
  return createStyleRule(componentName, layer, rule, [rule], value, isInvariant, pseudo, tokens);
};
const getMultipleStyleRule = (componentName, layer, rule, variables, value, isInvariant, pseudo, tokens) => {
  return createStyleRule(componentName, layer, rule, variables, value, isInvariant, pseudo, tokens);
};
const RULE_DEFAULTS = {
  translate: "0px",
  rotate: "0deg",
  scale: "1",
  "border-top-width": "0px",
  "border-right-width": "0px",
  "border-bottom-width": "0px",
  "border-left-width": "0px"
};
function createStyleRule(componentName, layer, rule, variables, value, isInvariant, pseudo, tokens) {
  const left = rule;
  const right = variables.map((variable, index) => {
    const ruleDef = RULE_DEFAULTS[rule];
    const variableValue = Array.isArray(value) ? value[index] : value;
    const baseCssVar = getBaseCssVariable(
      componentName,
      layer,
      variable,
      tokens?.["brandVersion"] === "jio-v2"
    );
    if (tokens && isInvariant && typeof variableValue !== "object") {
      const resolved = getValueFromPrimitive(rule, variableValue, tokens);
      if (resolved) {
        return resolved;
      }
    }
    if (tokens && typeof variableValue !== "object") {
      const resolved = getValueFromPrimitive(rule, variableValue, tokens);
      if (resolved) {
        if (ruleDef && resolved.includes("var(")) {
          const innermostVar = /var\(\s*--[^,)]+\)/;
          const resolvedWithDefault = resolved.replace(
            innermostVar,
            (match) => `${match.slice(0, -1)}, ${ruleDef})`
          );
          return `var(${baseCssVar}, ${resolvedWithDefault})`;
        }
        return `var(${baseCssVar}, ${resolved})`;
      }
    }
    const cssVar = ruleDef ? `var(${baseCssVar}, ${ruleDef})` : `var(${baseCssVar})`;
    return pseudo ? `var(${getCssVariable(
      componentName,
      layer,
      variable,
      tokens?.["brandVersion"] === "jio-v2",
      pseudo
    )}, ${cssVar})` : cssVar;
  }).join(" ");
  return { [left]: right };
}
function getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens) {
  return {
    [getCssVariable(
      componentName,
      layer,
      rule,
      tokens?.["brandVersion"] === "jio-v2" && !pseudo,
      pseudo
    )]: value?.toString()
  };
}
function handleRuleCSSVar(componentName, layer, rule, ruleVal, pseudo, layerMap, tokens) {
  if (rule in CSS_VAR_RULE_MAP) {
    return CSS_VAR_RULE_MAP[rule](componentName, layer, rule, ruleVal, pseudo, layerMap, tokens);
  }
  return {};
}
function handleRuleClass(rule, ruleVal, tokens, pseudo) {
  if (rule in CLASS_RULE_MAP) {
    return CLASS_RULE_MAP[rule](rule, ruleVal, tokens, pseudo);
  }
  return void 0;
}
const getLayerShortKey = (layer, length = 1) => layer.split("-").map((x, index, arr) => index !== arr.length - 1 ? x.slice(0, length) : x).filter(Boolean).join("-");
function drawLayer(componentName, layer, layerMap, invariantsMap, layerShortKey, pseudo, tokens) {
  const newTokens = { ...tokens };
  Object.keys(invariantsMap || {}).forEach((key2) => {
    if (key2 in newTokens) {
      newTokens[key2] = invariantsMap?.[key2]?.toString() ?? newTokens[key2];
    }
  });
  const brandDefaults = BrandStore.defaults ?? {};
  const layerCSSVars = {};
  const layerClasses = [];
  const key = !pseudo && getLayerType(layer);
  if (newTokens && newTokens?.["brandVersion"] === "jio-v2") {
    if (key && brandDefaults[key]) {
      layerMap = merge(brandDefaults[key] ?? {}, layerMap);
    }
  } else {
    if (key && (defaults[key] || brandDefaults[key])) {
      layerMap = merge(defaults[key] ?? {}, brandDefaults[key] ?? {}, layerMap);
    }
  }
  for (const rule in layerMap) {
    if (invariantsMap?.[rule]) {
      continue;
    }
    const useClasses = rule in CLASS_RULE_MAP && newTokens && newTokens?.["brandVersion"] === "jio-v2" && // String(layerMap[rule]).includes('&') &&
    !pseudo;
    if (useClasses) {
      const klass = handleRuleClass(rule, layerMap[rule], newTokens);
      if (klass) {
        layerClasses.push(klass);
        continue;
      }
      if (klass === null) {
        continue;
      }
    }
    Object.assign(
      layerCSSVars,
      handleRuleCSSVar(componentName, layerShortKey, rule, layerMap[rule], pseudo, layerMap, tokens)
    );
  }
  return {
    styles: layerCSSVars,
    classes: layerClasses
  };
}
const colorKeys = [
  "appearance",
  "surface",
  "strokeSurface",
  "color",
  "background-color",
  "border-color",
  "fill"
];
function getNewTokens(tokens, baseMap) {
  const colorProperty = Object.keys(baseMap || {}).find(
    (key) => key.endsWith("color") && !key.includes("border")
  );
  const borderColorProperty = Object.keys(baseMap || {}).find((key) => key.includes("border"));
  const colorToken = removeBraces(String(baseMap?.[colorProperty ?? ""]) || "");
  const borderColorToken = removeBraces(String(baseMap?.[borderColorProperty ?? ""]) || "");
  const surface = colorToken?.split("_")?.[2];
  const strokeSurface = borderColorToken?.split("_")?.[2];
  const baseSurface = baseMap?.["surface"]?.toString();
  const baseStrokeSurface = baseMap?.["strokeSurface"]?.toString();
  const newTokens = {
    ...tokens,
    surface: baseSurface || surface || tokens["surface"],
    strokeSurface: baseStrokeSurface || strokeSurface || tokens["strokeSurface"]
  };
  if (tokens?.["brandVersion"] === "jio-v2" && BrandStore.updateFlatTokens) {
    const updatedTokens = BrandStore.updateFlatTokens({ ...newTokens });
    updatedTokens["parentScale"] = newTokens["scale"];
    return updatedTokens;
  }
  return newTokens;
}
function handleVariant(component, base, variant, config) {
  for (const prop in variant) {
    if (prop in component) {
      const propValues = Object.keys(variant[prop]);
      const matchIndex = propValues.indexOf(getProp(component, prop));
      if (matchIndex > -1) {
        base = merge(base, variant[prop][propValues[matchIndex]]);
      }
    } else {
      base = merge(base, variant[prop][String(config?.[0]?.values?.[0])]);
    }
  }
  return base;
}
function getProp(component, prop) {
  return Object(component)[prop]?.toString?.() ?? "";
}
function handleCombinations(component, base, combinations, combinationConfigs, config) {
  combinationConfigs.forEach((combinationConfig, configIndex) => {
    let partialCombination = combinations[configIndex];
    for (const prop of combinationConfig) {
      if (prop in component && component[prop] !== void 0) {
        partialCombination = partialCombination[getProp(component, prop)];
      } else {
        const defaultValue = config?.[prop].values?.[0];
        if (typeof defaultValue !== "undefined") {
          partialCombination = partialCombination[defaultValue.toString()];
        }
      }
      if (!partialCombination) {
        break;
      }
    }
    base = merge(base, partialCombination);
  });
  return base;
}
function combineAllBases(json) {
  let combined = { ...json.base };
  for (const prop in json.variant) {
    const propObj = json.variant[prop];
    for (const key in propObj) {
      combined = mergeWithBooleanAnd(combined, propObj[key]);
    }
  }
  combined = getAllCombinations(combined, json);
  combined = combineBehaviors(combined);
  return combined;
}
function mergeWithBooleanAnd(base, second) {
  const merged = {};
  const keys = [...Object.keys(base), ...Object.keys(second)];
  for (const key of keys) {
    if (!(key in second)) {
      merged[key] = base[key];
    } else if (!(key in base)) {
      merged[key] = second[key];
    } else {
      merged[key] = mergeValues(base[key], second[key]);
    }
  }
  return merged;
}
function mergeValues(base, second) {
  if (isObject(base) && isObject(second)) {
    return mergeWithBooleanAnd(base, second);
  } else if (isArray(base) && isArray(second)) {
    return [...base, ...second];
  } else if (typeof base === "boolean" && typeof second === "boolean") {
    return base && second;
  }
  return second;
}
function isObject(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isArray(value) {
  return Array.isArray(value);
}
function getAllCombinations(combined, json) {
  const { combination, combination_config } = json;
  if (combination && combination_config) {
    for (let index = 0; index < combination_config.length; index++) {
      const config = combination_config[index];
      const comb = combination[index];
      combined = merge(combined, getCombination(comb, config));
    }
  }
  return combined;
}
function combineBehaviors(combined) {
  for (const layer in combined) {
    let baseMap = combined[layer];
    for (const pseudo in baseMap.behavior) {
      baseMap = merge(baseMap, baseMap.behavior[pseudo]);
    }
    combined[layer] = baseMap;
  }
  return combined;
}
function getCombination(currentCombination, configKeys) {
  if (configKeys.length === 0) {
    return {};
  } else if (configKeys.length === 1) {
    const bases = Object.values(currentCombination);
    return merge(bases[0], ...bases.slice(1));
  }
  const remainingKeys = configKeys.slice(1);
  const combinations = Object.values(currentCombination);
  let result = {};
  for (const comb of combinations) {
    const base = getCombination(comb, remainingKeys);
    result = merge(result, base);
  }
  return result;
}
const BufferConverter = (value) => {
  return Buffer.from(value, "base64").toString("utf-8");
};
const convertBase64ToObject = (value) => {
  if (!value)
    return {};
  const converter = typeof window === "undefined" ? BufferConverter : window.atob;
  const objectString = converter(value);
  return JSON.parse(objectString || "{}");
};
const convertToBase64 = (value) => {
  return window.btoa(JSON.stringify(value));
};
const percentageRegExp = /%([A-Za-z]+)/;
function getDefaultProps(api) {
  const config = api.config;
  const data = api.data;
  const defaultProps = {};
  for (const key in config) {
    const item = config[key];
    if (item.values) {
      const index = item.defaultIndex ?? 0;
      const value = item.values[index] ?? item.values[0];
      if (value) {
        defaultProps[key] = value;
      }
    }
  }
  for (const layer in data) {
    const datum = data[layer];
    for (const key in datum) {
      const item = datum[key];
      if (item.values) {
        const index = item.defaultIndex ?? 0;
        const value = item.values[index] ?? item.values[0];
        if (value) {
          defaultProps[key] = value;
        }
      }
    }
  }
  return defaultProps;
}
function getDefaultAppearance(api) {
  const { data, config } = api;
  if (config?.["appearance"]) {
    const item = config["appearance"];
    if (item.defaultIndex) {
      return item.values?.[item.defaultIndex].toString() ?? item.values?.[0].toString() ?? "auto";
    }
  } else {
    for (const layer in data) {
      const datum = data[layer];
      for (const key in datum) {
        const item = datum[key];
        if (item.name === "appearance" && item.type === "enum") {
          return item.values?.[0]?.toString() ?? "auto";
        }
      }
    }
  }
  return "auto";
}

function hasTokens(val) {
  return typeof val === "string" && /{.*}/.test(val);
}
const defaultCSSVarRuleHandler = (component, layer, rule, value, pseudo, _, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(rule, value, tokens);
  return getBaseCSSVarRule(component, layer, rule, value, pseudo, tokens);
};
const lineHeightCSSVarRuleHandler = (component, layer, rule, value, pseudo, _, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(rule, value, tokens);
  if (tokens?.["brandVersion"] === "jio-v2" && !String(value).endsWith("%"))
    value = `calc(${value} * 1%)`;
  return getBaseCSSVarRule(component, layer, rule, value, pseudo, tokens);
};
const colorCSSVarRuleHandler = (component, layer, rule, value, pseudo, _, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  const originalValue = value;
  value = getValueFromPrimitive(rule, value, tokens);
  if (String(originalValue).includes("elevated")) {
    const bgVarItems = String(value).split(",");
    const [bgColor, shadowColor, x1, y1, r1, x2, y2, r2, borderColor, borderWidth] = String(
      bgVarItems[1] || value
    ).split(";");
    return {
      ...getBaseCSSVarRule(component, layer, rule, bgColor, pseudo, tokens),
      ...borderWidth ? getBaseCSSVarRule(component, layer, "border-width", `${borderWidth}px`, pseudo, tokens) : {},
      ...x1 || x2 || y1 || y2 || r1 || r2 ? getBaseCSSVarRule(
        component,
        layer,
        "box-shadow",
        `${x1}px ${y1}px ${r1}px ${shadowColor}, ${x2}px ${y2}px ${r2}px ${shadowColor}`,
        pseudo,
        tokens
      ) : {},
      ...getBaseCSSVarRule(component, layer, "border-color", `${borderColor}`, pseudo, tokens)
    };
  }
  return getBaseCSSVarRule(component, layer, rule, value, pseudo, tokens);
};
const isCSSVar = (value) => value.startsWith("var(--");
const dimensionsCSSVarRuleHandler = (component, layer, rule, value, pseudo, _, tokens) => {
  const supportedValues = [
    "100%",
    "fit-content",
    "max",
    "min",
    "intrinsicSize.max",
    "intrinsicSize.min"
  ];
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  const layerParts = layer.split("-");
  const baseLayer = layerParts[layerParts.length - 1];
  value = getValueFromPrimitive(rule, value, tokens);
  if (!supportedValues.includes(value) && !isCSSVar(value)) {
    if (isNaN(parseFloat(value))) {
      value = layerDefaults[baseLayer]?.[rule];
    }
  }
  if (value === "max")
    value = "100%";
  if (value === "min")
    value = "fit-content";
  if (value === "intrinsicSize.max")
    value = "unset";
  return getBaseCSSVarRule(component, layer, rule, value, pseudo, tokens);
};
const borderGradientColorCSSVarRuleHandler = (component, layer, _, value, pseudo) => {
  if (typeof value === "object") {
    return handleBorderGradientColorObject(component, layer, "border-image", value, pseudo);
  }
  return defaultCSSVarRuleHandler(component, layer, "border-image", value, pseudo);
};
const backgroundGradientColorCSSVarRuleHandler = (component, layer, _, value, pseudo) => {
  if (typeof value === "object") {
    return handleBackgroundGradientColorObject(component, layer, "background-image", value, pseudo);
  }
  return defaultCSSVarRuleHandler(component, layer, "background-image", value, pseudo);
};
const handleBackgroundGradientColorObject = (componentName, layer, rule, ruleVal, pseudo, _layerMap, tokens) => {
  const { type, colors, angle } = ruleVal;
  const colorStops = Array.from(colors).join(",");
  if (type === "radial") {
    const resolvedValue = `radial-gradient(circle, ${colorStops})`;
    return getBaseCSSVarRule(componentName, layer, rule, resolvedValue, pseudo, tokens);
  } else if (type === "linear") {
    const degAngle = withUnits("rotate", angle ?? 180);
    const resolvedValue = `linear-gradient(${degAngle}, ${colorStops})`;
    return getBaseCSSVarRule(componentName, layer, rule, resolvedValue, pseudo, tokens);
  }
  console.warn("Unknown background gradient in", componentName, layer);
  return {};
};
const handleBorderGradientColorObject = (componentName, layer, rule, ruleVal, pseudo, _layerMap, tokens) => {
  const { type, colors, width } = ruleVal;
  const typeMap = {
    radial: "radial-gradient",
    linear: "linear-gradient"
  };
  const colorStops = colors.join(",");
  const resolvedValue = `${typeMap[type]}(circle,${colorStops}) ${width}`;
  return getBaseCSSVarRule(componentName, layer, rule, resolvedValue, pseudo, tokens);
};
const sizeCSSVarRuleHandler = (component, layer, _rule, value, pseudo, layerMap, tokens) => ({
  ...defaultCSSVarRuleHandler(component, layer, "height", value, pseudo, layerMap, tokens),
  ...dimensionsCSSVarRuleHandler(component, layer, "width", value, pseudo, layerMap, tokens)
});
const boxShadowCSSVarRuleHandler = (componentName, layer, rule, ruleVal, pseudo, layerMap, tokens) => {
  if (typeof ruleVal === "object") {
    return handleBoxShadowObject(
      componentName,
      layer,
      rule,
      ruleVal,
      pseudo,
      tokens
    );
  }
  return defaultCSSVarRuleHandler(componentName, layer, rule, ruleVal, pseudo, layerMap, tokens);
};
const boxShadowOrderedKeys = ["x", "y", "blur", "spread", "color"];
const BOX_SHADOW_RULE_MAP = {
  x: "padding",
  y: "padding",
  blur: "padding",
  spread: "padding",
  color: "color"
};
function handleBoxShadowObject(componentName, layer, rule, ruleVal, pseudo, tokens) {
  const values = [];
  for (const key of boxShadowOrderedKeys) {
    if (!(key in ruleVal)) {
      continue;
    }
    const value = ruleVal[key];
    const rule2 = BOX_SHADOW_RULE_MAP[key];
    const resolved = getValueFromPrimitive(rule2, value, tokens);
    values.push(resolved);
  }
  return getBaseCSSVarRule(componentName, layer, rule, values.join(" "), pseudo, tokens);
}
const flexDirectionCSSVarRuleHandler = (componentName, layer, rule, value, pseudo, _layerMap, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(rule, value, tokens);
  const result = {};
  let position = "static";
  if (value.includes("stack")) {
    value = "row";
    position = "relative";
  }
  Object.assign(
    result,
    getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens),
    getBaseCSSVarRule(componentName, layer, "position", position, pseudo, tokens)
  );
  return result;
};
const borderWidthCSSVarRuleHandler = (componentName, layer, rule, ruleVal, pseudo, _, tokens) => {
  if (typeof ruleVal === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  ruleVal = getValueFromPrimitive(rule, ruleVal, tokens);
  return getBaseCSSVarRule(componentName, layer, rule, ruleVal, pseudo, tokens);
};
const blurRadiusCSSVarRuleHandler = (componentName, layer, rule, ruleVal, pseudo, _layerMap, tokens) => {
  if (rule === "blur-radius") {
    rule = "filter";
  } else {
    rule = "backdrop-filter";
  }
  if (typeof ruleVal === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  ruleVal = getValueFromPrimitive(rule, ruleVal, tokens);
  ruleVal = `blur(${ruleVal})`;
  return getBaseCSSVarRule(componentName, layer, "filter", ruleVal, pseudo, tokens);
};
const borderRulesMap = {
  "border-radius": [
    "border-top-left-radius",
    "border-top-right-radius",
    "border-bottom-right-radius",
    "border-bottom-left-radius"
  ],
  "border-width": [
    "border-top-width",
    "border-right-width",
    "border-bottom-width",
    "border-left-width"
  ],
  "border-color": [
    "border-top-color",
    "border-right-color",
    "border-bottom-color",
    "border-left-color"
  ]
};
function getBorderRules(rule) {
  return borderRulesMap[rule] || [];
}
const borderCSSVarRuleHandler = (componentName, layer, rule, ruleVal, pseudo, _layerMap, tokens) => getBorderRules(rule).map((r) => {
  if (typeof ruleVal === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  ruleVal = getValueFromPrimitive(rule, ruleVal, tokens);
  return getBaseCSSVarRule(componentName, layer, r, ruleVal, pseudo, tokens);
}).reduce((a, b) => ({ ...a, ...b }), {});
const zIndexCSSVarRuleHandler = (componentName, layer, rule, value, pseudo, _layerMap, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(rule, value, tokens);
  let position = "static";
  const num = parseInt(value);
  if (num !== 0) {
    position = "absolute";
  }
  return {
    ...getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens),
    ...getBaseCSSVarRule(componentName, layer, "position", position, pseudo, tokens)
  };
};
const disabledCSSVarRuleHandler = (component, layer, _rule, value, pseudo, _layerMap, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive("pointer-events", value, tokens);
  value = !value || value === "false" ? "auto" : "none";
  return getBaseCSSVarRule(component, layer, "pointer-events", value, pseudo, tokens);
};
const paddingCSSVarRuleHandler = (componentName, layer, rule, value, pseudo, layerMap, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(rule, value, tokens);
  const paddingValue = getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens);
  const direction = rule.split("-")[1];
  const borderWidthRule = `border-${direction}-width`;
  const borderWidthValue = layerMap?.[borderWidthRule] || layerMap?.["border-width"];
  if (borderWidthValue) {
    const borderWidthCSSVar = borderWidthCSSVarRuleHandler(
      componentName,
      layer,
      borderWidthRule,
      borderWidthValue,
      pseudo,
      layerMap,
      tokens
    );
    const val = Object.values(borderWidthCSSVar)[0];
    if (val) {
      const key = Object.keys(paddingValue)[0];
      paddingValue[key] = `calc(${paddingValue[key]} - ${val})`;
    }
  }
  return paddingValue;
};
const buttonVectorRuleMap = {
  "fill-color": "color",
  "stroke-color": "color"
};
const skeletonRuleMap = {
  "primary-color": "color",
  "secondary-color": "color"
};
const inputRuleMap = {
  "inactive-color": "color",
  "active-color": "color",
  "ball-size": "height",
  "ball-color": "color",
  "ball-border-color": "color",
  "ball-border-width": "border-width",
  "track-height": "height",
  "placeholder-color": "color",
  "placeholder-font-family": "font-family",
  "placeholder-font-size": "font-size",
  "placeholder-line-height": "line-height",
  "placeholder-letter-spacing": "letter-spacing",
  "placeholder-font-weight": "font-weight",
  "input-color": "color",
  "input-font-family": "font-family",
  "input-font-size": "font-size",
  "input-line-height": "line-height",
  "input-letter-spacing": "letter-spacing",
  "input-font-weight": "font-weight",
  "resize-color": "color",
  "cursor-color": "color"
};
const inputCSSVarRuleHandler = (componentName, layer, rule, value, pseudo, _, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(inputRuleMap[rule], value, tokens);
  if (rule === "input-line-height") {
    return lineHeightCSSVarRuleHandler(componentName, layer, rule, value, pseudo, _, tokens);
  }
  return getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens);
};
const buttonVectorCSSVarRuleHandler = (componentName, layer, rule, value, pseudo, _layerMap, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(
    buttonVectorRuleMap[rule],
    value,
    tokens
  );
  return getBaseCSSVarRule(componentName, layer, `--${rule}`, value, pseudo, tokens);
};
const cursorCSSVarRuleHandler = (componentName, layer, _rule, value, pseudo, layerMap, tokens) => defaultCSSVarRuleHandler(componentName, layer, "cursor", value, pseudo, layerMap, tokens);
const skeletonCSSVarRuleHandler = (componentName, layer, rule, value, pseudo, _layerMap, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(
    skeletonRuleMap[rule],
    value,
    tokens
  );
  return getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens);
};
const transitonTimingFunctionHandler = (componentName, layer, rule, value, pseudo, _layerMap, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(rule, value, tokens);
  value = `cubic-bezier${value}`;
  return getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens);
};
const transitonDurationHandler = (componentName, layer, rule, value, pseudo, _layerMap, tokens) => {
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(rule, value, tokens);
  rule = "transition-duration";
  return getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens);
};
const transformCSSVarRuleHandler = (componentName, layer, rule, ruleVal, pseudo, layerMap, tokens) => {
  const [ruleName, direction] = rule.split("-");
  if (!direction) {
    return defaultCSSVarRuleHandler(
      componentName,
      layer,
      ruleName,
      ruleVal,
      pseudo,
      layerMap,
      tokens
    );
  }
  if (direction) {
    if (typeof ruleVal === "object") {
      console.warn("Cannot process Object directly");
      return {};
    }
    ruleVal = getValueFromPrimitive(ruleName, ruleVal, tokens);
    if (ruleName === "rotate") {
      ruleVal = `${direction} ${ruleVal}`;
    }
    return getBaseCSSVarRule(componentName, layer, rule, ruleVal, pseudo, tokens);
  }
  return {};
};
const TRANSITION_PROPERTY_MAP = {
  "translate-x": "translate",
  "translate-y": "translate",
  "translate-z": "translate",
  "scale-x": "scale",
  "scale-y": "scale",
  "scale-z": "scale",
  "rotate-x": "rotate",
  "rotate-y": "rotate",
  "rotate-z": "rotate"
};
const transitionCSSVarRuleHandler = (componentName, layer, _rule, value, pseudo, layerMap, tokens) => {
  if (typeof value !== "object" || !value) {
    console.warn("Transition needs to be object.");
    return {};
  }
  const { property, duration, "timing-function": timingFunction, delay } = value;
  const result = {};
  if (property) {
    const props = Array().concat(property);
    Object.assign(
      result,
      defaultCSSVarRuleHandler(
        componentName,
        layer,
        "transition-property",
        props.map((prop) => TRANSITION_PROPERTY_MAP[prop] ?? prop).join(", "),
        pseudo,
        layerMap,
        tokens
      )
    );
  }
  if (duration) {
    Object.assign(
      result,
      transitonDurationHandler(
        componentName,
        layer,
        "transition-duration",
        duration,
        pseudo,
        layerMap,
        tokens
      )
    );
  }
  if (timingFunction) {
    Object.assign(
      result,
      defaultCSSVarRuleHandler(
        componentName,
        layer,
        "transition-timing-function",
        timingFunction,
        pseudo,
        layerMap,
        tokens
      )
    );
  }
  if (delay) {
    Object.assign(
      result,
      defaultCSSVarRuleHandler(
        componentName,
        layer,
        "transition-delay",
        delay,
        pseudo,
        layerMap,
        tokens
      )
    );
  }
  return result;
};
const clipFirstHalfCSSVarRuleHandler = (componentName, layer, _rule, value, pseudo, _layerMap, tokens) => {
  const rule = "clip-path";
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(rule, value);
  const baseVar = getBaseCssVariable(
    componentName,
    layer,
    "--clip-value",
    tokens?.["brandVersion"] === "jio-v2"
  );
  if (value) {
    value = `inset(0 var(${baseVar}, 0) 0 0)`;
  } else {
    value = `inset(0 0 0 var(${baseVar}, 0))`;
  }
  return getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens);
};
const clipValueCSSVarRuleHandler = (componentName, layer, _rule, value, pseudo, layerMap, tokens) => {
  const rule = "clip-path";
  if (typeof value === "object") {
    console.warn("Cannot process Object directly");
    return {};
  }
  value = getValueFromPrimitive(rule, value, tokens);
  const clipFirstHalf = layerMap?.["clip-first-half"];
  if (clipFirstHalf) {
    value = `inset(0 ${value ?? 0} 0 0)`;
  } else {
    value = `inset(0 0 0 ${value ?? 0})`;
  }
  return getBaseCSSVarRule(componentName, layer, rule, value, pseudo, tokens);
};
const linearGradientOpacityHandler = (componentName, layer, _rule, value, pseudo, _layerMap, tokens) => {
  if (!Array.isArray(value)) {
    console.warn("Invalid color format", value);
    return {};
  }
  const cssVars = value.map((value2, i) => {
    const numberValue = value2.split("%")[0];
    const decimalValue = parseFloat(numberValue) + "%";
    return getBaseCSSVarRule(
      componentName,
      layer,
      "linear-gradient-opacity-" + i,
      decimalValue,
      pseudo,
      tokens
    );
  });
  return cssVars.reduce((acc, cssVar) => ({ ...acc, ...cssVar }), {});
};
const linearGradientHandler = (componentName, layer, _rule, value, pseudo, _layerMap, tokens) => {
  if (!Array.isArray(value)) {
    console.warn("Invalid color format", value);
    return {};
  }
  const colors = value.map((value2, i) => {
    const color = fetchTokenValue("color", value2, tokens || {});
    const opacity = `var(--${componentName.toLowerCase()}--${layer}-linear-gradient-opacity-${i})`;
    if (color.startsWith("oklch")) {
      return `oklch(from ${color} l c h / ${opacity})`;
    }
    const { r, g, b } = hexToRGB(color);
    return `rgba(${r},${g},${b}, )`;
  });
  const endCSSVar = `var(--${componentName.toLowerCase()}--${layer}-linear-gradient-end,bottom)`;
  const gradient = `linear-gradient(to ${endCSSVar},${colors.join(",")} )`;
  return getBaseCSSVarRule(componentName, layer, "background-image", gradient, pseudo, tokens);
};
const transitionCSSVarRules = {
  "transition-timing-function": transitonTimingFunctionHandler,
  "transition-duration": transitonDurationHandler,
  "transition-property": defaultCSSVarRuleHandler,
  "transition-delay": defaultCSSVarRuleHandler,
  transition: transitionCSSVarRuleHandler,
  "enter-animation-duration": transitonDurationHandler,
  "exit-animation-duration": transitonDurationHandler,
  "animation-duration": transitonDurationHandler
};
const inputCSSVarRules = {
  "inactive-color": inputCSSVarRuleHandler,
  "active-color": inputCSSVarRuleHandler,
  "ball-size": inputCSSVarRuleHandler,
  "ball-color": inputCSSVarRuleHandler,
  "ball-border-color": inputCSSVarRuleHandler,
  "ball-border-width": inputCSSVarRuleHandler,
  "track-height": inputCSSVarRuleHandler,
  "placeholder-color": inputCSSVarRuleHandler,
  "placeholder-font-family": inputCSSVarRuleHandler,
  "placeholder-font-size": inputCSSVarRuleHandler,
  "placeholder-line-height": inputCSSVarRuleHandler,
  "placeholder-letter-spacing": inputCSSVarRuleHandler,
  "placeholder-font-weight": inputCSSVarRuleHandler,
  "input-color": inputCSSVarRuleHandler,
  "input-font-family": inputCSSVarRuleHandler,
  "input-font-size": inputCSSVarRuleHandler,
  "input-line-height": inputCSSVarRuleHandler,
  "input-letter-spacing": inputCSSVarRuleHandler,
  "input-font-weight": inputCSSVarRuleHandler,
  "resize-color": inputCSSVarRuleHandler,
  "cursor-color": inputCSSVarRuleHandler
};
const skeletonCSSVarRules = {
  "primary-color": skeletonCSSVarRuleHandler,
  "secondary-color": skeletonCSSVarRuleHandler
};
const buttonVectorCSSVarRules = {
  "fill-color": buttonVectorCSSVarRuleHandler,
  "stroke-color": buttonVectorCSSVarRuleHandler
};
const clipCSSVarRules = {
  "clip-first-half": clipFirstHalfCSSVarRuleHandler,
  "clip-value": clipValueCSSVarRuleHandler
};
const CSS_VAR_RULE_MAP = {
  "align-items": defaultCSSVarRuleHandler,
  "aspect-ratio": defaultCSSVarRuleHandler,
  "background-blur": blurRadiusCSSVarRuleHandler,
  "background-gradient-color": backgroundGradientColorCSSVarRuleHandler,
  "background-image": defaultCSSVarRuleHandler,
  "background-repeat": defaultCSSVarRuleHandler,
  "blur-radius": blurRadiusCSSVarRuleHandler,
  "border-color": borderCSSVarRuleHandler,
  "border-radius": borderCSSVarRuleHandler,
  "border-style": defaultCSSVarRuleHandler,
  "border-width": borderCSSVarRuleHandler,
  "border-top-width": borderWidthCSSVarRuleHandler,
  "border-right-width": borderWidthCSSVarRuleHandler,
  "border-bottom-width": borderWidthCSSVarRuleHandler,
  "border-left-width": borderWidthCSSVarRuleHandler,
  "border-top-color": defaultCSSVarRuleHandler,
  "border-right-color": defaultCSSVarRuleHandler,
  "border-bottom-color": defaultCSSVarRuleHandler,
  "border-left-color": defaultCSSVarRuleHandler,
  "border-gradient-color": borderGradientColorCSSVarRuleHandler,
  "border-top-left-radius": defaultCSSVarRuleHandler,
  "border-top-right-radius": defaultCSSVarRuleHandler,
  "border-bottom-right-radius": defaultCSSVarRuleHandler,
  "border-bottom-left-radius": defaultCSSVarRuleHandler,
  bottom: defaultCSSVarRuleHandler,
  "box-shadow": boxShadowCSSVarRuleHandler,
  "box-sizing": defaultCSSVarRuleHandler,
  cursor: cursorCSSVarRuleHandler,
  display: defaultCSSVarRuleHandler,
  disabled: disabledCSSVarRuleHandler,
  flex: defaultCSSVarRuleHandler,
  "flex-shrink": defaultCSSVarRuleHandler,
  "flex-direction": flexDirectionCSSVarRuleHandler,
  "flex-wrap": defaultCSSVarRuleHandler,
  "font-family": defaultCSSVarRuleHandler,
  "font-size": defaultCSSVarRuleHandler,
  "font-weight": defaultCSSVarRuleHandler,
  gap: defaultCSSVarRuleHandler,
  height: dimensionsCSSVarRuleHandler,
  "justify-content": defaultCSSVarRuleHandler,
  left: defaultCSSVarRuleHandler,
  "letter-spacing": defaultCSSVarRuleHandler,
  "line-height": lineHeightCSSVarRuleHandler,
  "max-height": dimensionsCSSVarRuleHandler,
  "max-width": dimensionsCSSVarRuleHandler,
  "min-height": dimensionsCSSVarRuleHandler,
  "min-width": dimensionsCSSVarRuleHandler,
  opacity: defaultCSSVarRuleHandler,
  outline: defaultCSSVarRuleHandler,
  overflow: defaultCSSVarRuleHandler,
  "padding-bottom": paddingCSSVarRuleHandler,
  "padding-left": paddingCSSVarRuleHandler,
  "padding-right": paddingCSSVarRuleHandler,
  "padding-top": paddingCSSVarRuleHandler,
  "pointer-events": defaultCSSVarRuleHandler,
  position: defaultCSSVarRuleHandler,
  right: defaultCSSVarRuleHandler,
  rotate: defaultCSSVarRuleHandler,
  "rotate-x": transformCSSVarRuleHandler,
  "rotate-y": transformCSSVarRuleHandler,
  "rotate-z": transformCSSVarRuleHandler,
  translate: transformCSSVarRuleHandler,
  "translate-x": transformCSSVarRuleHandler,
  "translate-y": transformCSSVarRuleHandler,
  "translate-z": transformCSSVarRuleHandler,
  scale: transformCSSVarRuleHandler,
  "scale-x": transformCSSVarRuleHandler,
  "scale-y": transformCSSVarRuleHandler,
  "scale-z": transformCSSVarRuleHandler,
  "text-align": defaultCSSVarRuleHandler,
  "text-decoration": defaultCSSVarRuleHandler,
  "text-overflow": defaultCSSVarRuleHandler,
  "text-transform": defaultCSSVarRuleHandler,
  "object-fit": defaultCSSVarRuleHandler,
  "object-position": defaultCSSVarRuleHandler,
  size: sizeCSSVarRuleHandler,
  up: defaultCSSVarRuleHandler,
  "web-cursor": cursorCSSVarRuleHandler,
  width: dimensionsCSSVarRuleHandler,
  "z-index": zIndexCSSVarRuleHandler,
  "linear-gradient-start": defaultCSSVarRuleHandler,
  "linear-gradient-end": defaultCSSVarRuleHandler,
  "linear-gradient-colors": linearGradientHandler,
  "linear-gradient-opacity": linearGradientOpacityHandler,
  ...inputCSSVarRules,
  ...skeletonCSSVarRules,
  ...transitionCSSVarRules,
  ...buttonVectorCSSVarRules,
  ...clipCSSVarRules,
  "font-style": defaultCSSVarRuleHandler,
  color: colorCSSVarRuleHandler,
  "background-color": colorCSSVarRuleHandler
};
function getValueFromPrimitive(rule, value, tokens) {
  if (value?.toString().includes("&")) {
    return fetchTokenValue(rule, String(value), tokens || {});
  }
  if (hasTokens(value)) {
    value = fetchTokenVariable(rule, value);
  } else {
    value = withUnits(rule, value);
  }
  return value;
}
const getCssVarFromToken = (tokenString) => `--${kebabcase(removeBraces(tokenString.replace(/\./g, "-")))}`;

class Color {
  color;
  colorInstance;
  alpha = 1;
  constructor(color, alpha = 1) {
    this.color = color;
    this.alpha = alpha;
    if (!this.colorInstance) {
      this.colorInstance = new Color(color);
    }
  }
  to(format) {
    console.info(format);
    return this.colorInstance;
  }
  toString(data) {
    console.info(data);
    return this.color;
  }
  mix(color, value) {
    console.info(color, value);
    return this.colorInstance;
  }
}

const alphaColorModifier = (hexColor, alpha) => {
  let color = new Color(hexColor);
  color = color.to("hsl");
  color.alpha = Math.max(0, Math.min(1, Number(alpha)));
  const newColor = new Color(color.toString({ inGamut: true, precision: 3 }));
  return newColor.to("srgb").toString({
    format: "hex"
  });
};
const mixColorModifier = (firstColor, secondColor, parameter) => {
  const color = new Color(firstColor);
  const mixColor = new Color(secondColor.toString());
  const mixValue = Math.max(0, Math.min(1, Number(parameter)));
  const newColor = new Color(color.mix(mixColor, mixValue).toString({}));
  return newColor.to("srgb").toString({
    format: "hex"
  });
};
const COLOR_MODIFIER_MAP = {
  alpha: alphaColorModifier,
  mix: mixColorModifier
};

const functionRegex = /(\w+)\(([\w.# ,-]+)\)/;
const mulRegex = /(-?[\d.]+)\*(-?[\d.]+)/;
const divRegex = /(-?[\d.]+)\/(-?[\d.]+)/;
const addRegex = /(-?[\d.]+)\+(-?[\d.]+)/;
const subRegex = /(-?[\d.]+)-(-?[\d.]+)/;
const expRegex = /(-?[\d.]+)\^(-?[\d.]+)/;
const parensRegex = /\((-?[\d.]+)\)/;
function colorModify(args) {
  const [type, ...values] = args;
  try {
    return COLOR_MODIFIER_MAP[type](...values);
  } catch (e) {
    console.warn("wrong input for type in colorModifier: ", type);
    return "";
  }
}
const functionMap = {
  floor: ([value]) => Math.floor(parseFloat(value)).toString(),
  round: ([value]) => Math.round(parseFloat(value)).toString(),
  min: (args) => Math.min(...args.map(parseFloat)).toString(),
  max: (args) => Math.max(...args.map(parseFloat)).toString(),
  colorModify
};
const operators = [
  [
    expRegex,
    (first, second) => (parseFloat(first) ** parseFloat(second)).toString()
  ],
  [
    mulRegex,
    (first, second) => (parseFloat(first) * parseFloat(second)).toString()
  ],
  [
    divRegex,
    (first, second) => (parseFloat(first) / parseFloat(second)).toString()
  ],
  [
    addRegex,
    (first, second) => (parseFloat(first) + parseFloat(second)).toString()
  ],
  [
    subRegex,
    (first, second) => (parseFloat(first) - parseFloat(second)).toString()
  ],
  [
    functionRegex,
    (name, argsString) => {
      if (name in functionMap) {
        return functionMap[name](argsString.split(","));
      }
      return "";
    }
  ],
  [parensRegex, (value) => value]
];
function parseMaths(key) {
  if (!operators.find(([op]) => op.test(key)))
    return key;
  let value = key.replace(/[ ']/g, "");
  let operator;
  while (operator = operators.find(([op]) => op.test(value))) {
    const [op, callback] = operator;
    const match = value.match(op);
    if (match) {
      const left = match[1];
      const right = match[2];
      const replacement = callback(left, right);
      const replaced = value.replace(op, replacement);
      if (replaced === "") {
        break;
      }
      value = replaced.replace(/ /g, "");
    }
  }
  return value;
}

const colorJsons = ["color"];
const borderRadiusJsons = ["borderRadius"];
const sizeJsons = ["sizing", "layout"];
const borderWidthJsons = ["borderWidth", ...sizeJsons];
const letterSpacingJSONs = ["letterSpacing", "typography"];
const fontSizeJsons = ["fontSizes"];
const lineHeightJsons = ["lineHeights", "typography"];
const fontFamilyJsons = ["fontFamilies", "typography"];
const fontWeightJsons = ["fontWeights", "typography"];
const spacingJsons = ["spacing"];
const otherJsons = ["layout"];
const opacityJsons = ["opacity"];
const shadowsJsons = ["shadows"];
const textDecorationJsons = ["textDecoration"];
const textTransformJsons = ["textCase"];
const transitionDurationJSONs = ["transitionsDuration"];
const transitionTimingFunctionJSONs = ["transitions"];
const RULE_JSON_MAP = {
  "background-color": colorJsons,
  "background-image": colorJsons,
  "border-color": colorJsons,
  "border-top-color": colorJsons,
  "border-right-color": colorJsons,
  "border-bottom-color": colorJsons,
  "border-left-color": colorJsons,
  color: colorJsons,
  "border-radius": borderRadiusJsons,
  "border-top-left-radius": borderRadiusJsons,
  "border-top-right-radius": borderRadiusJsons,
  "border-bottom-right-radius": borderRadiusJsons,
  "border-bottom-left-radius": borderRadiusJsons,
  "border-width": borderWidthJsons,
  "border-top-width": borderWidthJsons,
  "border-right-width": borderWidthJsons,
  "border-bottom-width": borderWidthJsons,
  "border-left-width": borderWidthJsons,
  "blur-radius": sizeJsons,
  filter: sizeJsons,
  height: sizeJsons,
  "max-height": sizeJsons,
  "min-height": sizeJsons,
  width: sizeJsons,
  "max-width": sizeJsons,
  "min-width": sizeJsons,
  size: sizeJsons,
  "font-size": fontSizeJsons,
  "line-height": lineHeightJsons,
  "font-family": fontFamilyJsons,
  "font-weight": fontWeightJsons,
  gap: spacingJsons,
  padding: spacingJsons,
  "padding-left": spacingJsons,
  "padding-right": spacingJsons,
  "padding-top": spacingJsons,
  "padding-bottom": spacingJsons,
  "box-shadow": shadowsJsons,
  "text-decoration": textDecorationJsons,
  opacity: opacityJsons,
  "aspect-ratio": otherJsons,
  "flex-direction": otherJsons,
  "align-items": otherJsons,
  "justify-content": otherJsons,
  display: otherJsons,
  "font-style": otherJsons,
  outline: otherJsons,
  "text-align": otherJsons,
  rotate: otherJsons,
  "letter-spacing": letterSpacingJSONs,
  "border-gradient-color": colorJsons,
  "linear-gradient-colors": colorJsons,
  "text-transform": textTransformJsons,
  "enter-animation-duration": transitionDurationJSONs,
  "exit-animation-duration": transitionDurationJSONs,
  "transition-timing-function": transitionTimingFunctionJSONs,
  "transition-duration": transitionDurationJSONs,
  "transition-property": otherJsons
};
const RN_TOKEN_OVERRIDES = {
  "{label.3xs.lineheight}": "110.00000238418579"
  // Add more React Native specific overrides here
};
class BrandStore {
  static constants = {};
  static defaults;
  static fetchTokenMemo = {};
  static switchablesMemo = {};
  static componentTokensMemo = {};
  static brandSwitchableFn;
  static updateFlatTokens;
  static brandResolverFn;
  static brandComponentFn;
  static getDensityMap;
  static getColorsMap;
  static getSwitchables(tokens) {
    const tokensKey = JSON.stringify(tokens);
    const switchables = this.switchablesMemo[tokensKey] ?? this.brandSwitchableFn?.(tokens) ?? {};
    this.switchablesMemo[tokensKey] = switchables;
    return switchables;
  }
  /**
   * Use this to register the brand provided by the user
   * @param brand The brand object to register
   */
  static registerBrand(brand) {
    this.constants = brand.tokens;
    this.defaults = brand.defaults;
    this.brandSwitchableFn = brand.getSwitchableTokens;
    this.brandComponentFn = brand.getComponentTokens;
    this.brandResolverFn = brand.brandResolverFn;
    this.updateFlatTokens = brand.updateFlatTokens;
    this.getDensityMap = brand.getDensityMap;
    this.getColorsMap = brand.getColorsMap;
    this.fetchTokenMemo = {};
    this.switchablesMemo = {};
    this.componentTokensMemo = {};
  }
  static registerAdditionalTokens(tokens) {
    this.constants["extras"] = tokens;
  }
  static getValue(rule, key, tokens, forceValue) {
    if (BrandStore.brandResolverFn && String(key).includes("&")) {
      const { value: brandValue, key: brandKey } = BrandStore.brandResolverFn(rule, key, tokens || {}, forceValue) ?? {};
      if (brandKey) {
        if (!forceValue)
          return `var(${getCssVarFromToken(brandKey.replace(/f-(\d+)/, "f-m$1"))})`;
        return brandValue;
      }
      if (typeof brandValue !== "undefined") {
        return withUnits(rule, brandValue);
      }
    }
    const [jsonKey, ...fallbacks] = RULE_JSON_MAP[rule] ?? [];
    if (!jsonKey) {
      return void 0;
    }
    let json = this.constants[jsonKey];
    const switchables = this.getSwitchables(tokens);
    if (!json) {
      json = switchables?.[jsonKey];
    }
    if (this.constants["extras"]) {
      fallbacks.push("extras");
    }
    let value = json?.[key];
    if (value === void 0) {
      for (const fallback2 of fallbacks) {
        json = this.constants[fallback2] ?? switchables?.[fallback2];
        value = json?.[key];
        if (value !== void 0) {
          break;
        }
      }
    }
    return value;
  }
  static getComponentToken(key, metaCompName) {
    key = removeBraces(key);
    if (metaCompName in this.componentTokensMemo) {
      return this.componentTokensMemo[metaCompName]?.[key];
    }
    const compTokens = this.brandComponentFn?.(metaCompName);
    this.componentTokensMemo[metaCompName] = compTokens;
    return compTokens?.[key];
  }
  static getApplicableTokens(tokens) {
    const switchables = this.getSwitchables(tokens);
    const merged = merge(this.constants, switchables);
    const tokenKeys = Object.keys(tokens);
    const result = {};
    for (const folderKey in merged) {
      const folder = merged[folderKey];
      const filtered = Object.entries(folder || {}).reduce((acc, [key, value]) => {
        if (typeof value === "string" && tokenKeys.some(
          (token) => value.includes(`$${token}`)
          // || value.includes('&')
        )) {
          acc[key] = value;
        }
        return acc;
      }, {});
      result[folderKey] = filtered;
    }
    return result;
  }
}
const assignTypes = {
  sizing: "size",
  spacing: "padding",
  "font-families": "font-family",
  "font-sizes": "font-size",
  "font-weights": "font-weight",
  "line-heights": "line-height",
  "text-case": "text-transform",
  "transitions-duration": "transition-duration",
  transitions: "transition-timing-function",
  typography: "font-family",
  lineHeights: "line-height",
  fontFamilies: "font-family",
  letterSpacing: "letter-spacing",
  fontWeights: "font-weight",
  fontSizes: "font-size",
  textCase: "text-transform",
  platform: "size"
};
function fetchTokenFromFolder(folder, key, tokens) {
  const rule = assignTypes[folder] ?? folder;
  return fetchTokenValue(rule, key, tokens);
}
function fetchTokenValue(rule, key, tokens, forceValue = false) {
  const memoKey = getMemoKey(rule, key, tokens);
  if (memoKey in BrandStore.fetchTokenMemo) {
    return BrandStore.fetchTokenMemo[memoKey];
  }
  let raw = parseKey(rule, key, tokens, forceValue);
  if (RN_TOKEN_OVERRIDES[key]) {
    raw = RN_TOKEN_OVERRIDES[key];
  }
  let value = String(key)?.includes("column") ? raw : withUnits(rule, raw);
  if (rule === "line-height" && tokens?.["brandVersion"] === "jio-v2") {
    value = value.replace("px", "%");
  }
  if (RULE_JSON_MAP[rule]?.includes("sizing")) {
    value = value === "max" ? "100%" : value;
    value = value === "min" ? "100%" : value;
    value = value === "negativeMax" ? "-100%" : value;
    value = value === "intrinsicSize.max" ? "max-content" : value;
  }
  if (rule?.includes("transition-timing-function")) {
    value = `cubic-bezier(${value})`;
  }
  BrandStore.fetchTokenMemo[memoKey] = value;
  return value;
}
const getNestedFallbacks = (variables) => {
  if (variables.length > 1) {
    return `var(${variables[0]}, ${getNestedFallbacks(variables.slice(1))})`;
  }
  return `var(${variables[0]})`;
};
function fetchTokenVariable(rule, key) {
  const jsons = RULE_JSON_MAP[rule] ?? otherJsons;
  return getNestedFallbacks(jsons.map((json) => getCssVarFromToken(json ? `${json}-${key}` : key)));
}
const tokenReg = /{([\w\-.$]+)}/;
const pureTokenReg = /^{([&%?\w\-.]+)}$/;
const pureTokenRegWithSwitchable = /^{([&%?\w\-.$]+)}$/;
const pureValue = /^[[\],\w\d?%\-. #$]+$/;
function getMemoKey(rule, key, tokens) {
  return rule + key + JSON.stringify(tokens);
}
function parseKey(rule, key, tokens, forceValue) {
  let value;
  if (pureTokenReg.test(key)) {
    key = removeBraces(key);
    value = BrandStore.getValue(rule, key, tokens, forceValue);
  } else if (pureTokenRegWithSwitchable.test(key)) {
    key = replaceTokens(removeBraces(key), tokens);
    value = BrandStore.getValue(rule, key, tokens, forceValue);
  } else {
    value = key;
  }
  if (value === void 0) {
    if (key.includes("typography")) {
      return key;
    }
    return "";
  } else if (typeof value !== "string") {
    return value.toString();
  }
  if (pureTokenReg.test(value)) {
    return parseKey(rule, value, tokens, forceValue);
  }
  if (pureTokenRegWithSwitchable.test(value)) {
    if (Object.keys(tokens).length === 0) {
      console.warn(`No tokens provided, cannot resolve ${key}, ${value}`);
      return "";
    }
    const switched = replaceTokens(value, tokens);
    return parseKey(rule, switched, tokens, forceValue);
  }
  if (tokenReg.test(value)) {
    value = handleNonPureTokens(rule, value, tokens, forceValue);
  }
  if (pureValue.test(value) || value.startsWith("color-mix")) {
    return value;
  }
  const mathParsed = parseMaths(value);
  return mathParsed;
}
function handleNonPureTokens(rule, value, tokens, forceValue) {
  let match;
  while (match = tokenReg.exec(value)) {
    const replacement = parseKey(rule, match[0], tokens, forceValue);
    value = value.replace(tokenReg, replacement);
  }
  return value;
}
const UNITS_MAP = {
  filter: "px",
  "backdrop-filter": "px",
  "background-blur": "px",
  "blur-radius": "px",
  "border-radius": "px",
  "border-top-left-radius": "px",
  "border-top-right-radius": "px",
  "border-bottom-right-radius": "px",
  "border-bottom-left-radius": "px",
  "border-width": "px",
  "border-top-width": "px",
  "border-right-width": "px",
  "border-bottom-width": "px",
  "border-left-width": "px",
  height: "px",
  width: "px",
  size: "px",
  "font-size": "px",
  "line-height": "px",
  gap: "px",
  padding: "px",
  "padding-left": "px",
  "padding-right": "px",
  "padding-top": "px",
  "padding-bottom": "px",
  "letter-spacing": "px",
  outline: "%",
  rotate: "deg",
  "transition-duration": "ms",
  "transition-delay": "ms",
  "exit-animation-duration": "ms",
  "enter-animation-duration": "ms",
  "animation-duration": "ms"
};
const unitRules = Object.keys(UNITS_MAP);
const units = ["px", "%", "deg", "vw", "em", "rem", "vh", "ms"];
function needsUnits(value, match) {
  const notString = typeof value !== "string";
  const noMatch = !match;
  if (notString || noMatch) {
    return Boolean(match);
  }
  const isNotNumber = isNaN(parseInt(value));
  const hasUnits = units.some((unit) => value.includes(unit));
  return !(isNotNumber || hasUnits);
}
function withUnits(rule, value) {
  const match = unitRules.find((unit) => rule.includes(unit)) ?? "";
  if (needsUnits(value, match)) {
    return `${value}${UNITS_MAP[match]}`;
  }
  return value.toString();
}
const fallback = {
  lang: "en",
  platform: "desktop"
};
function replaceTokens(key, tokens) {
  tokens = { ...fallback, ...tokens };
  return Object.entries(tokens).filter(([, value]) => value).reduce((key2, [token, value]) => {
    return key2.replace(RegExp(`\\$${token}`, "g"), value.toString());
  }, key);
}

const permittedKeys = /* @__PURE__ */ new Set([
  "slot_layers",
  "hidden",
  "show",
  "behavior",
  "value",
  "web-tag"
]);
function getAllRequiredBaseLayers(base, props, getAllAmpersandTokenLayers = false, getPercentageTokens = []) {
  const hiddenLayers = {};
  for (const layer in base) {
    const layerObj = base[layer];
    const layerKey = getLayerType(layer);
    for (const key in layerObj) {
      const value = layerObj[key];
      if (typeof value !== "string") {
        hiddenLayers[layer] ??= {};
        hiddenLayers[layer][key] = value;
        continue;
      }
      const hasAmpersandKey = typeof value === "string" && value.includes("&") && (value.includes("stroke") || key.includes("color") || key.includes("fill"));
      const hasPercentKey = typeof value === "string" && value.includes("%");
      const matchedKey = hasPercentKey && value.match(percentageRegExp)?.[1];
      const hasPercentToken = matchedKey && getPercentageTokens.includes(matchedKey);
      if (getAllAmpersandTokenLayers && hasAmpersandKey || hasPercentToken || permittedKeys.has(key) || layerKey?.startsWith("jds_") || // include all molecule layers
      layerKey?.endsWith("arc")) {
        hiddenLayers[layer] ??= {};
        hiddenLayers[layer][key] = hasPercentKey ? replacePercentageTokens(value, props) : value;
      }
    }
  }
  return hiddenLayers;
}
function replacePercentageTokens(value, props) {
  const match = value.match(percentageRegExp);
  if (!match) {
    return value;
  }
  const key = match[1];
  const replacement = props[key];
  if (replacement === void 0) {
    return value;
  }
  return value.replace(
    `%${key}`,
    replacement?.toString() ?? ""
  );
}
function getLayersProps(component, json, config = {
  transformer: false,
  getAmpersandTokens: false,
  getAllBaseLayers: true,
  getPercentageTokens: []
}) {
  const {
    transformer = false,
    getAllBaseLayers = false,
    getAmpersandTokens = false,
    getPercentageTokens = []
  } = config;
  let base = getAllBaseLayers ? deepClone(json.base) : getAllRequiredBaseLayers(
    deepClone(json.base),
    component,
    getAmpersandTokens,
    getPercentageTokens
  );
  base = handleVariant(component, base, json.variant, json.api.config);
  if (json.combination && json.combination_config) {
    base = handleCombinations(
      component,
      base,
      json.combination,
      json.combination_config,
      json.api.config
    );
  }
  base = withComponentTokens(base, json.metadata?.["name"]);
  return json.api.data && !transformer ? removeNoDataLayers(base, component, json.api.data) : base;
}
function removeNoDataLayers(base, component, data) {
  for (const layer in base) {
    if (base[layer]["hidden"]) {
      continue;
    }
    const layerType = getLayerType(layer);
    const datum = data[layer];
    if (layerType === "icon" || layerType === "text" || layerType === "image") {
      const value = datum?.["value"];
      const name = value?.name;
      if (!name || name.includes(".")) {
        continue;
      }
      const val = component[value.name] || base[layer]["value"];
      if (val === void 0 || val === null || val === "") {
        base[layer]["hidden"] = true;
      }
    }
  }
  return base;
}
function drawComponent(componentName, base, hierarchy, invariants = {}, tokens) {
  const layerKeySet = /* @__PURE__ */ new Set();
  return drawComponentHierarchy(
    componentName,
    hierarchy,
    base,
    invariants,
    layerKeySet,
    tokens
  );
}
function drawComponentHierarchy(componentName, hierarchy, base, invariants, layerKeySet, tokens) {
  const root = getRoot(hierarchy) || hierarchy;
  if (BrandStore.updateFlatTokens && tokens && tokens?.["brandVersion"] === "jio-v2" && // layerKey === 'container' && // not sure
  Object.keys(base[root] ?? {}).some((key) => colorKeys.includes(key))) {
    tokens = getNewTokens(tokens, base[root]);
  }
  const children = typeof hierarchy === "string" ? [] : hierarchy[root];
  const { styles: rootVars, classes: rootClasses } = drawComponentBase(
    componentName,
    root,
    base[root],
    invariants[root],
    tokens
  );
  if (children?.length) {
    const childrenVars = {};
    const childrenClasses = {};
    let hasVisibleChildren = false;
    for (const child of children) {
      const childRoot = typeof child === "string" ? child : getRoot(child);
      if (typeof child === "string") {
        let newTokens = tokens;
        if (BrandStore.updateFlatTokens && tokens && tokens?.["brandVersion"] === "jio-v2" && // layerKey === 'container' && // not sure
        Object.keys(base[childRoot] ?? {}).some(
          (key) => colorKeys.includes(key)
        )) {
          newTokens = getNewTokens(tokens, base[childRoot]);
        }
        const visible = !base[child]?.["hidden"];
        hasVisibleChildren ||= visible;
        const childVars = drawComponentBase(
          componentName,
          child,
          base[child],
          invariants[child],
          newTokens
        );
        Object.assign(childrenVars, childVars.styles);
        Object.assign(childrenClasses, childVars.classes);
      } else {
        const childLayer = getRoot(child);
        const childVars = drawComponentHierarchy(
          componentName,
          child,
          base,
          invariants,
          layerKeySet,
          tokens
        );
        const visible = !base[childLayer]?.["hidden"];
        hasVisibleChildren ||= visible;
        Object.assign(childrenVars, childVars.styles);
        Object.assign(childrenClasses, childVars.classes);
      }
    }
    const combinedVars = { ...rootVars, ...childrenVars };
    const combinedClasses = { ...rootClasses, ...childrenClasses };
    base[root] ??= {};
    if (hasVisibleChildren || base[root]["show"]) {
      return { styles: combinedVars, classes: combinedClasses };
    }
    base[root]["hidden"] = true;
    return { styles: combinedVars, classes: combinedClasses };
  }
  return { styles: rootVars, classes: rootClasses };
}
function drawComponentBase(componentName, layer, baseMap, invariantsMap, tokens) {
  if (!baseMap) {
    return { styles: {}, classes: {} };
  }
  const baseCSSVars = {};
  const baseClasses = {};
  const { behavior = {}, ...layerObj } = baseMap;
  const layerKey = getLayerType(layer);
  const isV3 = tokens?.["brandVersion"] === "jio-v2";
  const { styles: layerStyle, classes: layerClasses } = drawLayer(
    componentName,
    layer,
    layerObj,
    isV3 ? invariantsMap : {},
    layer,
    void 0,
    tokens
  );
  if (isV3 && layerKey && [
    "icon",
    "text",
    "jds_text2",
    "jds_icon2",
    "container",
    "jds_container2"
  ].includes(layerKey)) {
    behavior["hover"] = behavior["hover"] || {};
    behavior["active"] = behavior["active"] || {};
    if (layerKey === "icon" || layerKey === "text" || layerKey === "jds_text2" || layerKey === "jds_icon2") {
      if (layerObj["color"]) {
        behavior["hover"]["color"] = layerObj["color"];
        behavior["active"]["color"] = layerObj["color"];
      }
    } else {
      if (layerObj["background-color"]) {
        behavior["hover"]["background-color"] = layerObj["background-color"];
        behavior["active"]["background-color"] = layerObj["background-color"];
      }
      if (layerObj["border-color"]) {
        behavior["hover"]["border-color"] = layerObj["border-color"];
        behavior["active"]["border-color"] = layerObj["border-color"];
      }
    }
  }
  Object.assign(baseCSSVars, layerStyle);
  baseClasses[layer] = layerClasses;
  for (const pseudo in behavior) {
    const merged = merge(layerObj, behavior[pseudo]);
    const behaviorInvariants = invariantsMap?.behavior?.[pseudo];
    const { styles: pseudoLayerStyle, classes: pseudoLayerClasses } = drawLayer(
      componentName,
      layer,
      isV3 ? behavior[pseudo] : merged,
      isV3 ? behaviorInvariants : void 0,
      layer,
      pseudo,
      tokens ? { ...tokens, state: pseudo } : void 0
    );
    Object.assign(baseCSSVars, pseudoLayerStyle);
    baseClasses[layer] = baseClasses[layer].concat(pseudoLayerClasses);
  }
  return { styles: baseCSSVars, classes: baseClasses };
}
const getCustomJSON = (custom) => {
  const [, base64] = custom?.split("--") || [];
  const convertedCustom = convertBase64ToObject(base64);
  return convertedCustom;
};
function withComponentTokensHelper(baseMap, metaCompName, fallback) {
  for (const key in baseMap) {
    const value = baseMap[key];
    if (typeof value === "object") {
      baseMap[key] = withComponentTokensHelper(
        baseMap[key],
        metaCompName,
        fallback
      );
    } else if (typeof value === "string") {
      const replacement = metaCompName ? BrandStore.getComponentToken(value, metaCompName) : void 0;
      let icon, text;
      if (fallback === "icon") {
        icon = BrandStore.getComponentToken(value, "JDSIcon");
      } else if (fallback === "text") {
        text = BrandStore.getComponentToken(value, "JDSText");
      }
      baseMap[key] = replacement ?? icon ?? text ?? value;
    }
  }
  return baseMap;
}
function withComponentTokens(base, metaCompName) {
  for (const layer in base) {
    const baseMap = base[layer];
    const fallback = layer.includes("icon") ? "icon" : layer.includes("text") ? "text" : void 0;
    base[layer] = withComponentTokensHelper(baseMap, metaCompName, fallback);
  }
  return base;
}

function performanceWrapper(func, details) {
  const start = performance.now();
  const result = func();
  const end = performance.now();
  setTimeout(() => {
    console.log(
      `Time Taken${details ? ` for ${details}` : ""}: ${end - start}`
    );
  });
  return result;
}
const assignDefaultValues = (reference, defaultValues) => {
  Object.keys(defaultValues).forEach((prop) => {
    if (reference[prop] === void 0) {
      reference[prop] = defaultValues[prop];
    }
  });
  return reference;
};
const isHexValid = (hex) => {
  const hexRegex = /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3}|[A-Fa-f0-9]{8})$/;
  return hexRegex.test(hex);
};

export { BrandStore, CLASS_RULE_MAP, CSS_VAR_RULE_MAP, RULE_JSON_MAP, assignDefaultValues, colorKeys, combineAllBases, convertBase64ToObject, convertToBase64, drawComponent, drawLayer, fetchTokenFromFolder, fetchTokenValue, fetchTokenVariable, getAllLayers, getBaseCSSVarRule, getBaseCssVariable, getBaseStyleRule, getCssVarFromToken, getCssVariable, getCustomJSON, getDefaultAppearance, getDefaultProps, getInvariants, getLayerClass, getLayerShortKey, getLayerTestId, getLayerType, getLayersProps, getMultipleStyleRule, getNewTokens, getRoot, getValueFromPrimitive, handleCombinations, handleRuleCSSVar, handleRuleClass, handleVariant, hasTokens, isHexValid, layerDefaults, percentageRegExp, performanceWrapper, replacePercentageTokens, units, withComponentTokens, withUnits };
